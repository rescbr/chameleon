typedef struct {
	char*	symbol;
	unsigned int	addr;
} symbol_t;

static char _AllocateKernelMemory_string[] = "_AllocateKernelMemory";
static char _AllocateMemoryRange_string[] = "_AllocateMemoryRange";
static char _BeFSGetDescription_string[] = "_BeFSGetDescription";
static char _BeFSProbe_string[] = "_BeFSProbe";
static char _BinaryUnicodeCompare_string[] = "_BinaryUnicodeCompare";
static char _CacheInit_string[] = "_CacheInit";
static char _CacheRead_string[] = "_CacheRead";
static char _CacheReset_string[] = "_CacheReset";
static char _CreateUUIDString_string[] = "_CreateUUIDString";
static char _DT__AddChild_string[] = "_DT__AddChild";
static char _DT__AddProperty_string[] = "_DT__AddProperty";
static char _DT__Finalize_string[] = "_DT__Finalize";
static char _DT__FindNode_string[] = "_DT__FindNode";
static char _DT__FlattenDeviceTree_string[] = "_DT__FlattenDeviceTree";
static char _DT__FreeNode_string[] = "_DT__FreeNode";
static char _DT__FreeProperty_string[] = "_DT__FreeProperty";
static char _DT__GetName_string[] = "_DT__GetName";
static char _DT__Initialize_string[] = "_DT__Initialize";
static char _DecodeKernel_string[] = "_DecodeKernel";
static char _DecodeMachO_string[] = "_DecodeMachO";
static char _EX2GetDescription_string[] = "_EX2GetDescription";
static char _EX2Probe_string[] = "_EX2Probe";
static char _EXFATGetDescription_string[] = "_EXFATGetDescription";
static char _EXFATGetUUID_string[] = "_EXFATGetUUID";
static char _EXFATProbe_string[] = "_EXFATProbe";
static char _FastRelString_string[] = "_FastRelString";
static char _FastUnicodeCompare_string[] = "_FastUnicodeCompare";
static char _FileLoadBundles_string[] = "_FileLoadBundles";
static char _FileLoadDrivers_string[] = "_FileLoadDrivers";
static char _FindAcpiTables_string[] = "_FindAcpiTables";
static char _FreeBSDGetDescription_string[] = "_FreeBSDGetDescription";
static char _FreeBSDProbe_string[] = "_FreeBSDProbe";
static char _GPT_BASICDATA2_GUID_string[] = "_GPT_BASICDATA2_GUID";
static char _GPT_BASICDATA_GUID_string[] = "_GPT_BASICDATA_GUID";
static char _GPT_BOOT_GUID_string[] = "_GPT_BOOT_GUID";
static char _GPT_EFISYS_GUID_string[] = "_GPT_EFISYS_GUID";
static char _GPT_HFS_GUID_string[] = "_GPT_HFS_GUID";
static char _Gdt_string[] = "_Gdt";
static char _Gdtr_string[] = "_Gdtr";
static char _GetBundleDict_string[] = "_GetBundleDict";
static char _GetBundlePath_string[] = "_GetBundlePath";
static char _GetBundlePersonality_string[] = "_GetBundlePersonality";
static char _GetChecksum_string[] = "_GetChecksum";
static char _GetDirEntry_string[] = "_GetDirEntry";
static char _GetFileInfo_string[] = "_GetFileInfo";
static char _GetgPlatformName_string[] = "_GetgPlatformName";
static char _GetgRootDevice_string[] = "_GetgRootDevice";
static char _Getgboardproduct_string[] = "_Getgboardproduct";
static char _HFSFree_string[] = "_HFSFree";
static char _HFSGetDescription_string[] = "_HFSGetDescription";
static char _HFSGetDirEntry_string[] = "_HFSGetDirEntry";
static char _HFSGetFileBlock_string[] = "_HFSGetFileBlock";
static char _HFSGetUUID_string[] = "_HFSGetUUID";
static char _HFSInitPartition_string[] = "_HFSInitPartition";
static char _HFSLoadFile_string[] = "_HFSLoadFile";
static char _HFSProbe_string[] = "_HFSProbe";
static char _HFSReadFile_string[] = "_HFSReadFile";
static char _Idtr_prot_string[] = "_Idtr_prot";
static char _Idtr_real_string[] = "_Idtr_real";
static char _InitBootPrompt_string[] = "_InitBootPrompt";
static char _InitBundleSupport_string[] = "_InitBundleSupport";
static char _InitDriverSupport_string[] = "_InitDriverSupport";
static char _LoadBundlePList_string[] = "_LoadBundlePList";
static char _LoadBundles_string[] = "_LoadBundles";
static char _LoadDriverMKext_string[] = "_LoadDriverMKext";
static char _LoadDriverPList_string[] = "_LoadDriverPList";
static char _LoadDrivers_string[] = "_LoadDrivers";
static char _LoadFile_string[] = "_LoadFile";
static char _LoadMatchedBundles_string[] = "_LoadMatchedBundles";
static char _LoadMatchedModules_string[] = "_LoadMatchedModules";
static char _LoadThinFatFile_string[] = "_LoadThinFatFile";
static char _LoadVolumeFile_string[] = "_LoadVolumeFile";
static char _MD5Final_string[] = "_MD5Final";
static char _MD5Init_string[] = "_MD5Init";
static char _MD5Update_string[] = "_MD5Update";
static char _MSDOSFree_string[] = "_MSDOSFree";
static char _MSDOSGetDescription_string[] = "_MSDOSGetDescription";
static char _MSDOSGetDirEntry_string[] = "_MSDOSGetDirEntry";
static char _MSDOSGetFileBlock_string[] = "_MSDOSGetFileBlock";
static char _MSDOSGetUUID_string[] = "_MSDOSGetUUID";
static char _MSDOSInitPartition_string[] = "_MSDOSInitPartition";
static char _MSDOSLoadFile_string[] = "_MSDOSLoadFile";
static char _MSDOSProbe_string[] = "_MSDOSProbe";
static char _MSDOSReadFile_string[] = "_MSDOSReadFile";
static char _MatchBundlesLibraries_string[] = "_MatchBundlesLibraries";
static char _MatchLibraries_string[] = "_MatchLibraries";
static char _NTFSGetDescription_string[] = "_NTFSGetDescription";
static char _NTFSGetUUID_string[] = "_NTFSGetUUID";
static char _NTFSProbe_string[] = "_NTFSProbe";
static char _OpenBSDGetDescription_string[] = "_OpenBSDGetDescription";
static char _OpenBSDProbe_string[] = "_OpenBSDProbe";
static char _ParseXMLFile_string[] = "_ParseXMLFile";
static char _Register_Acpi_Efi_string[] = "_Register_Acpi_Efi";
static char _Register_Smbios_Efi_string[] = "_Register_Smbios_Efi";
static char _SetgPlatformName_string[] = "_SetgPlatformName";
static char _SetgRootDevice_string[] = "_SetgRootDevice";
static char _Setgboardproduct_string[] = "_Setgboardproduct";
static char _ThinFatFile_string[] = "_ThinFatFile";
static char _XMLCastArray_string[] = "_XMLCastArray";
static char _XMLCastBoolean_string[] = "_XMLCastBoolean";
static char _XMLCastDict_string[] = "_XMLCastDict";
static char _XMLCastInteger_string[] = "_XMLCastInteger";
static char _XMLCastString_string[] = "_XMLCastString";
static char _XMLCastStringOffset_string[] = "_XMLCastStringOffset";
static char _XMLDecode_string[] = "_XMLDecode";
static char _XMLFreeTag_string[] = "_XMLFreeTag";
static char _XMLGetElement_string[] = "_XMLGetElement";
static char _XMLGetProperty_string[] = "_XMLGetProperty";
static char _XMLIsType_string[] = "_XMLIsType";
static char _XMLParseFile_string[] = "_XMLParseFile";
static char _XMLParseNextTag_string[] = "_XMLParseNextTag";
static char _XMLTagCount_string[] = "_XMLTagCount";
static char __DATA__bss__begin_string[] = "__DATA__bss__begin";
static char __DATA__bss__end_string[] = "__DATA__bss__end";
static char __DATA__common__begin_string[] = "__DATA__common__begin";
static char __DATA__common__end_string[] = "__DATA__common__end";
static char ___bzero_string[] = "___bzero";
static char ___convertImage_string[] = "___convertImage";
static char ___decodeRLE_string[] = "___decodeRLE";
static char ___divdi3_string[] = "___divdi3";
static char ___doprnt_string[] = "___doprnt";
static char ___drawColorRectangle_string[] = "___drawColorRectangle";
static char ___drawDataRectangle_string[] = "___drawDataRectangle";
static char ___getNumberArrayFromProperty_string[] = "___getNumberArrayFromProperty";
static char ___getVESAModeWithProperties_string[] = "___getVESAModeWithProperties";
static char ___moddi3_string[] = "___moddi3";
static char ___qdivrem_string[] = "___qdivrem";
static char ___setVESAGraphicsMode_string[] = "___setVESAGraphicsMode";
static char ___setVideoMode_string[] = "___setVideoMode";
static char ___udivdi3_string[] = "___udivdi3";
static char ___umoddi3_string[] = "___umoddi3";
static char __bp_string[] = "__bp";
static char __doprnt_truncates_string[] = "__doprnt_truncates";
static char __hi_malloc_string[] = "__hi_malloc";
static char __hi_strdup_string[] = "__hi_strdup";
static char __prot_to_real_string[] = "__prot_to_real";
static char __real_to_prot_string[] = "__real_to_prot";
static char __sp_string[] = "__sp";
static char __switch_stack_string[] = "__switch_stack";
static char _addBootArg_string[] = "_addBootArg";
static char _addConfigurationTable_string[] = "_addConfigurationTable";
static char _add_symbol_string[] = "_add_symbol";
static char _adler32_string[] = "_adler32";
static char _arc4_init_string[] = "_arc4_init";
static char _arc4random_string[] = "_arc4random";
static char _arc4random_addrandom_string[] = "_arc4random_addrandom";
static char _arc4random_buf_string[] = "_arc4random_buf";
static char _arc4random_stir_string[] = "_arc4random_stir";
static char _arc4random_uniform_string[] = "_arc4random_uniform";
static char _atoi_string[] = "_atoi";
static char _bcopy_string[] = "_bcopy";
static char _bcopy16_string[] = "_bcopy16";
static char _bcopy_no_overwrite_string[] = "_bcopy_no_overwrite";
static char _bgetc_string[] = "_bgetc";
static char _bind_location_string[] = "_bind_location";
static char _bind_macho_string[] = "_bind_macho";
static char _bios_string[] = "_bios";
static char _biosDevIsCDROM_string[] = "_biosDevIsCDROM";
static char _biosread_string[] = "_biosread";
static char _boot_string[] = "_boot";
static char _bootArgs_string[] = "_bootArgs";
static char _bootArgsLegacy_string[] = "_bootArgsLegacy";
static char _bootInfo_string[] = "_bootInfo";
static char _bsearch_string[] = "_bsearch";
static char _build_pci_dt_string[] = "_build_pci_dt";
static char _bzero_string[] = "_bzero";
static char _chainLoad_string[] = "_chainLoad";
static char _chainbootdev_string[] = "_chainbootdev";
static char _chainbootflag_string[] = "_chainbootflag";
static char _clearBootArgs_string[] = "_clearBootArgs";
static char _clearScreenRows_string[] = "_clearScreenRows";
static char _close_string[] = "_close";
static char _common_boot_string[] = "_common_boot";
static char _continue_at_low_address_string[] = "_continue_at_low_address";
static char _convertHexStr2Binary_string[] = "_convertHexStr2Binary";
static char _copyArgument_string[] = "_copyArgument";
static char _copyMultibootInfo_string[] = "_copyMultibootInfo";
static char _crc32_string[] = "_crc32";
static char _debug_putc_string[] = "_debug_putc";
static char _decompress_lzss_string[] = "_decompress_lzss";
static char _delay_string[] = "_delay";
static char _determine_safe_hi_addr_string[] = "_determine_safe_hi_addr";
static char _devprop_add_device_string[] = "_devprop_add_device";
static char _devprop_add_value_string[] = "_devprop_add_value";
static char _devprop_create_string_string[] = "_devprop_create_string";
static char _devprop_free_string_string[] = "_devprop_free_string";
static char _devprop_generate_string_string[] = "_devprop_generate_string";
static char _devprop_make_device_string[] = "_devprop_make_device";
static char _diskFreeMap_string[] = "_diskFreeMap";
static char _diskIsCDROM_string[] = "_diskIsCDROM";
static char _diskRead_string[] = "_diskRead";
static char _diskResetBootVolumes_string[] = "_diskResetBootVolumes";
static char _diskScanBootVolumes_string[] = "_diskScanBootVolumes";
static char _diskSeek_string[] = "_diskSeek";
static char _dump_pci_dt_string[] = "_dump_pci_dt";
static char _ebiosEjectMedia_string[] = "_ebiosEjectMedia";
static char _ebiosread_string[] = "_ebiosread";
static char _ebioswrite_string[] = "_ebioswrite";
static char _efi_guid_compare_string[] = "_efi_guid_compare";
static char _efi_guid_is_null_string[] = "_efi_guid_is_null";
static char _efi_guid_unparse_upper_string[] = "_efi_guid_unparse_upper";
static char _efi_inject_get_devprop_string_string[] = "_efi_inject_get_devprop_string";
static char _enableA20_string[] = "_enableA20";
static char _enable_pci_devs_string[] = "_enable_pci_devs";
static char _ents_string[] = "_ents";
static char _error_string[] = "_error";
static char _execute_hook_string[] = "_execute_hook";
static char _file_size_string[] = "_file_size";
static char _finalizeBootStruct_string[] = "_finalizeBootStruct";
static char _finalizeEFIConfigTable_string[] = "_finalizeEFIConfigTable";
static char _free_string[] = "_free";
static char _freeFilteredBVChain_string[] = "_freeFilteredBVChain";
static char _free_platform_env_string[] = "_free_platform_env";
static char _gAppleBootPictRLE_string[] = "_gAppleBootPictRLE";
static char _gCompareTable_string[] = "_gCompareTable";
static char _gCompareTableCompressed_string[] = "_gCompareTableCompressed";
static char _gEfiAcpi20TableGuid_string[] = "_gEfiAcpi20TableGuid";
static char _gEfiAcpiTableGuid_string[] = "_gEfiAcpiTableGuid";
static char _gEfiConfigurationTable32_string[] = "_gEfiConfigurationTable32";
static char _gEfiConfigurationTable64_string[] = "_gEfiConfigurationTable64";
static char _gEfiConfigurationTableNode_string[] = "_gEfiConfigurationTableNode";
static char _gEfiSmbiosTableGuid_string[] = "_gEfiSmbiosTableGuid";
static char _gLowerCaseTable_string[] = "_gLowerCaseTable";
static char _gLowerCaseTableCompressed_string[] = "_gLowerCaseTableCompressed";
static char _gNumTables32_string[] = "_gNumTables32";
static char _gNumTables64_string[] = "_gNumTables64";
static char _gST32_string[] = "_gST32";
static char _gST64_string[] = "_gST64";
static char _getBVChainForBIOSDev_string[] = "_getBVChainForBIOSDev";
static char _getBoolForKey_string[] = "_getBoolForKey";
static char _getBootArgs_string[] = "_getBootArgs";
static char _getBootOptions_string[] = "_getBootOptions";
static char _getBootVolumeDescription_string[] = "_getBootVolumeDescription";
static char _getBootVolumeRef_string[] = "_getBootVolumeRef";
static char _getBvChain_string[] = "_getBvChain";
static char _getConventionalMemorySize_string[] = "_getConventionalMemorySize";
static char _getCursorPositionAndType_string[] = "_getCursorPositionAndType";
static char _getDeviceDescription_string[] = "_getDeviceDescription";
static char _getExtendedMemorySize_string[] = "_getExtendedMemorySize";
static char _getIntForKey_string[] = "_getIntForKey";
static char _getKernelCachePath_string[] = "_getKernelCachePath";
static char _getMemoryInfoString_string[] = "_getMemoryInfoString";
static char _getMemoryMap_string[] = "_getMemoryMap";
static char _getNextArg_string[] = "_getNextArg";
static char _getPciRootUID_string[] = "_getPciRootUID";
static char _getPlatformName_string[] = "_getPlatformName";
static char _getSmbiosOriginal_string[] = "_getSmbiosOriginal";
static char _getStringForKey_string[] = "_getStringForKey";
static char _getStringFromUUID_string[] = "_getStringFromUUID";
static char _getUUIDFromString_string[] = "_getUUIDFromString";
static char _getVBEInfo_string[] = "_getVBEInfo";
static char _getVBEModeInfo_string[] = "_getVBEModeInfo";
static char _getValueForBootKey_string[] = "_getValueForBootKey";
static char _getValueForConfigTableKey_string[] = "_getValueForConfigTableKey";
static char _getValueForKey_string[] = "_getValueForKey";
static char _getVideoMode_string[] = "_getVideoMode";
static char _getVolumeLabelAlias_string[] = "_getVolumeLabelAlias";
static char _get_callback_string[] = "_get_callback";
static char _get_drive_info_string[] = "_get_drive_info";
static char _get_env_string[] = "_get_env";
static char _get_env_ptr_string[] = "_get_env_ptr";
static char _get_env_var_string[] = "_get_env_var";
static char _get_num_tables_string[] = "_get_num_tables";
static char _get_num_tables64_string[] = "_get_num_tables64";
static char _getc_string[] = "_getc";
static char _getchar_string[] = "_getchar";
static char _gettimeofday_string[] = "_gettimeofday";
static char _halt_string[] = "_halt";
static char _handle_symtable_string[] = "_handle_symtable";
static char _hi_multiboot_string[] = "_hi_multiboot";
static char _initBooterLog_string[] = "_initBooterLog";
static char _initKernBootStruct_string[] = "_initKernBootStruct";
static char _init_ut_fnc_string[] = "_init_ut_fnc";
static char _initialize_runtime_string[] = "_initialize_runtime";
static char _iob_from_fdesc_string[] = "_iob_from_fdesc";
static char _is_no_emulation_string[] = "_is_no_emulation";
static char _jump_to_chainbooter_string[] = "_jump_to_chainbooter";
static char _loadBooterConfig_string[] = "_loadBooterConfig";
static char _loadConfigFile_string[] = "_loadConfigFile";
static char _loadOverrideConfig_string[] = "_loadOverrideConfig";
static char _loadSystemConfig_string[] = "_loadSystemConfig";
static char _localVPrintf_string[] = "_localVPrintf";
static char _longjmp_string[] = "_longjmp";
static char _lookup_all_symbols_string[] = "_lookup_all_symbols";
static char _lookup_symbol_string[] = "_lookup_symbol";
static char _lspci_string[] = "_lspci";
static char _malloc_string[] = "_malloc";
static char _malloc_init_string[] = "_malloc_init";
static char _matchVolumeToString_string[] = "_matchVolumeToString";
static char _memcmp_string[] = "_memcmp";
static char _memcpy_string[] = "_memcpy";
static char _memmove_string[] = "_memmove";
static char _memset_string[] = "_memset";
static char _moduleCallbacks_string[] = "_moduleCallbacks";
static char _moduleSymbols_string[] = "_moduleSymbols";
static char _msglog_string[] = "_msglog";
static char _multiboot_to_boot_string[] = "_multiboot_to_boot";
static char _newEmptyStringWithLength_string[] = "_newEmptyStringWithLength";
static char _newFilteredBVChain_string[] = "_newFilteredBVChain";
static char _newGPTBVRef_string[] = "_newGPTBVRef";
static char _newString_string[] = "_newString";
static char _newStringForKey_string[] = "_newStringForKey";
static char _newStringWithFormat_string[] = "_newStringWithFormat";
static char _newStringWithLength_string[] = "_newStringWithLength";
static char _open_string[] = "_open";
static char _open_bvdev_string[] = "_open_bvdev";
static char _parse_mach_string[] = "_parse_mach";
static char _pause_string[] = "_pause";
static char _pci_config_read16_string[] = "_pci_config_read16";
static char _pci_config_read32_string[] = "_pci_config_read32";
static char _pci_config_read8_string[] = "_pci_config_read8";
static char _pci_config_write16_string[] = "_pci_config_write16";
static char _pci_config_write32_string[] = "_pci_config_write32";
static char _pci_config_write8_string[] = "_pci_config_write8";
static char _platform_env_string[] = "_platform_env";
static char _prf_string[] = "_prf";
static char _printMemoryInfo_string[] = "_printMemoryInfo";
static char _printf_string[] = "_printf";
static char _processBootOptions_string[] = "_processBootOptions";
static char _promptForRescanOption_string[] = "_promptForRescanOption";
static char _putc_string[] = "_putc";
static char _putca_string[] = "_putca";
static char _putchar_string[] = "_putchar";
static char _re_set_env_string[] = "_re_set_env";
static char _re_set_env_copy_string[] = "_re_set_env_copy";
static char _read_string[] = "_read";
static char _readBootSector_string[] = "_readBootSector";
static char _readDefaultPlatformName_string[] = "_readDefaultPlatformName";
static char _readKeyboardShiftFlags_string[] = "_readKeyboardShiftFlags";
static char _readKeyboardStatus_string[] = "_readKeyboardStatus";
static char _readSMBIOS_string[] = "_readSMBIOS";
static char _realloc_string[] = "_realloc";
static char _reallyVPrint_string[] = "_reallyVPrint";
static char _rebase_location_string[] = "_rebase_location";
static char _rebase_macho_string[] = "_rebase_macho";
static char _register_hook_callback_string[] = "_register_hook_callback";
static char _replace_function_string[] = "_replace_function";
static char _replace_function_any_string[] = "_replace_function_any";
static char _replace_system_function_string[] = "_replace_system_function";
static char _rescanBIOSDevice_string[] = "_rescanBIOSDevice";
static char _reserveKernBootStruct_string[] = "_reserveKernBootStruct";
static char _reserveKernLegacyBootStruct_string[] = "_reserveKernLegacyBootStruct";
static char _resolveConfig_string[] = "_resolveConfig";
static char _root_pci_dev_string[] = "_root_pci_dev";
static char _rtc_read_clock_string[] = "_rtc_read_clock";
static char _safe_set_env_string[] = "_safe_set_env";
static char _safe_set_env_copy_string[] = "_safe_set_env_copy";
static char _scanBootVolumes_string[] = "_scanBootVolumes";
static char _scanDisks_string[] = "_scanDisks";
static char _scan_cpu_string[] = "_scan_cpu";
static char _scan_pci_bus_string[] = "_scan_pci_bus";
static char _scan_platform_string[] = "_scan_platform";
static char _scollPage_string[] = "_scollPage";
static char _selectBootVolume_string[] = "_selectBootVolume";
static char _setActiveDisplayPage_string[] = "_setActiveDisplayPage";
static char _setBootArgsVideoMode_string[] = "_setBootArgsVideoMode";
static char _setBootArgsVideoStruct_string[] = "_setBootArgsVideoStruct";
static char _setBootGlobals_string[] = "_setBootGlobals";
static char _setCursorPosition_string[] = "_setCursorPosition";
static char _setCursorType_string[] = "_setCursorType";
static char _setRootVolume_string[] = "_setRootVolume";
static char _setVBEMode_string[] = "_setVBEMode";
static char _setVBEPalette_string[] = "_setVBEPalette";
static char _set_env_string[] = "_set_env";
static char _set_env_copy_string[] = "_set_env_copy";
static char _setjmp_string[] = "_setjmp";
static char _setupBooterLog_string[] = "_setupBooterLog";
static char _setupDeviceProperties_string[] = "_setupDeviceProperties";
static char _setupFakeEfi_string[] = "_setupFakeEfi";
static char _setupSmbiosConfigFile_string[] = "_setupSmbiosConfigFile";
static char _setup_acpi_string[] = "_setup_acpi";
static char _setup_pci_devs_string[] = "_setup_pci_devs";
static char _showError_string[] = "_showError";
static char _showHelp_string[] = "_showHelp";
static char _showMessage_string[] = "_showMessage";
static char _showTextBuffer_string[] = "_showTextBuffer";
static char _showTextFile_string[] = "_showTextFile";
static char _sleep_string[] = "_sleep";
static char _snprintf_string[] = "_snprintf";
static char _sprintf_string[] = "_sprintf";
static char _startprog_string[] = "_startprog";
static char _stop_string[] = "_stop";
static char _strbreak_string[] = "_strbreak";
static char _strcat_string[] = "_strcat";
static char _strchr_string[] = "_strchr";
static char _strcmp_string[] = "_strcmp";
static char _strcpy_string[] = "_strcpy";
static char _strdup_string[] = "_strdup";
static char _strlcat_string[] = "_strlcat";
static char _strlcpy_string[] = "_strlcpy";
static char _strlen_string[] = "_strlen";
static char _strncat_string[] = "_strncat";
static char _strncmp_string[] = "_strncmp";
static char _strncpy_string[] = "_strncpy";
static char _strstr_string[] = "_strstr";
static char _strtol_string[] = "_strtol";
static char _strtoul_string[] = "_strtoul";
static char _testBiosread_string[] = "_testBiosread";
static char _testFAT32EFIBootSector_string[] = "_testFAT32EFIBootSector";
static char _textAddress_string[] = "_textAddress";
static char _textSection_string[] = "_textSection";
static char _time18_string[] = "_time18";
static char _unset_env_string[] = "_unset_env";
static char _uterror_string[] = "_uterror";
static char _utf_decodestr_string[] = "_utf_decodestr";
static char _utf_encodestr_string[] = "_utf_encodestr";
static char _verbose_string[] = "_verbose";
static char _video_mode_string[] = "_video_mode";
static char _vsnprintf_string[] = "_vsnprintf";
static char _waitThenReload_string[] = "_waitThenReload";
static char _write_string[] = "_write";
static char _zalloced_size_string[] = "_zalloced_size";
static char _zout_string[] = "_zout";
static char boot2_string[] = "boot2";
symbol_t symbolList[] = {
	{.symbol = _AllocateKernelMemory_string, .addr = 0x0002cb3f},
	{.symbol = _AllocateMemoryRange_string, .addr = 0x0002cbb7},
	{.symbol = _BeFSGetDescription_string, .addr = 0x0002fd68},
	{.symbol = _BeFSProbe_string, .addr = 0x0002fd4f},
	{.symbol = _BinaryUnicodeCompare_string, .addr = 0x000342ea},
	{.symbol = _CacheInit_string, .addr = 0x0002ff43},
	{.symbol = _CacheRead_string, .addr = 0x0002fe01},
	{.symbol = _CacheReset_string, .addr = 0x0002fdf2},
	{.symbol = _CreateUUIDString_string, .addr = 0x000252d5},
	{.symbol = _DT__AddChild_string, .addr = 0x000332ef},
	{.symbol = _DT__AddProperty_string, .addr = 0x0003308d},
	{.symbol = _DT__Finalize_string, .addr = 0x0003324f},
	{.symbol = _DT__FindNode_string, .addr = 0x0003340c},
	{.symbol = _DT__FlattenDeviceTree_string, .addr = 0x000331df},
	{.symbol = _DT__FreeNode_string, .addr = 0x00033044},
	{.symbol = _DT__FreeProperty_string, .addr = 0x0003302e},
	{.symbol = _DT__GetName_string, .addr = 0x0003305a},
	{.symbol = _DT__Initialize_string, .addr = 0x000333ae},
	{.symbol = _DecodeKernel_string, .addr = 0x00022b95},
	{.symbol = _DecodeMachO_string, .addr = 0x0002cc01},
	{.symbol = _EX2GetDescription_string, .addr = 0x00030018},
	{.symbol = _EX2Probe_string, .addr = 0x0002ffff},
	{.symbol = _EXFATGetDescription_string, .addr = 0x00034778},
	{.symbol = _EXFATGetUUID_string, .addr = 0x00034702},
	{.symbol = _EXFATProbe_string, .addr = 0x000346df},
	{.symbol = _FastRelString_string, .addr = 0x00034404},
	{.symbol = _FastUnicodeCompare_string, .addr = 0x00034484},
	{.symbol = _FileLoadBundles_string, .addr = 0x00026f9c},
	{.symbol = _FileLoadDrivers_string, .addr = 0x000226fa},
	{.symbol = _FindAcpiTables_string, .addr = 0x00033674},
	{.symbol = _FreeBSDGetDescription_string, .addr = 0x000300c5},
	{.symbol = _FreeBSDProbe_string, .addr = 0x000300ac},
	{.symbol = _GPT_BASICDATA2_GUID_string, .addr = 0x00039b20},
	{.symbol = _GPT_BASICDATA_GUID_string, .addr = 0x00039b10},
	{.symbol = _GPT_BOOT_GUID_string, .addr = 0x00039af0},
	{.symbol = _GPT_EFISYS_GUID_string, .addr = 0x00039b00},
	{.symbol = _GPT_HFS_GUID_string, .addr = 0x00039ae0},
	{.symbol = _Gdt_string, .addr = 0x000204bc},
	{.symbol = _Gdtr_string, .addr = 0x000204f4},
	{.symbol = _GetBundleDict_string, .addr = 0x0002673e},
	{.symbol = _GetBundlePath_string, .addr = 0x0002670e},
	{.symbol = _GetBundlePersonality_string, .addr = 0x00026726},
	{.symbol = _GetChecksum_string, .addr = 0x00033558},
	{.symbol = _GetDirEntry_string, .addr = 0x00024f22},
	{.symbol = _GetFileInfo_string, .addr = 0x00025210},
	{.symbol = _GetgPlatformName_string, .addr = 0x0002562b},
	{.symbol = _GetgRootDevice_string, .addr = 0x0002563f},
	{.symbol = _Getgboardproduct_string, .addr = 0x00025635},
	{.symbol = _HFSFree_string, .addr = 0x00030326},
	{.symbol = _HFSGetDescription_string, .addr = 0x00031645},
	{.symbol = _HFSGetDirEntry_string, .addr = 0x00031338},
	{.symbol = _HFSGetFileBlock_string, .addr = 0x000316f7},
	{.symbol = _HFSGetUUID_string, .addr = 0x00031300},
	{.symbol = _HFSInitPartition_string, .addr = 0x00030fba},
	{.symbol = _HFSLoadFile_string, .addr = 0x000315f2},
	{.symbol = _HFSProbe_string, .addr = 0x00031615},
	{.symbol = _HFSReadFile_string, .addr = 0x00031427},
	{.symbol = _Idtr_prot_string, .addr = 0x00020504},
	{.symbol = _Idtr_real_string, .addr = 0x000204fc},
	{.symbol = _InitBootPrompt_string, .addr = 0x00022d2e},
	{.symbol = _InitBundleSupport_string, .addr = 0x00026b3a},
	{.symbol = _InitDriverSupport_string, .addr = 0x00022880},
	{.symbol = _LoadBundlePList_string, .addr = 0x00026c22},
	{.symbol = _LoadBundles_string, .addr = 0x00027946},
	{.symbol = _LoadDriverMKext_string, .addr = 0x0002225c},
	{.symbol = _LoadDriverPList_string, .addr = 0x00022323},
	{.symbol = _LoadDrivers_string, .addr = 0x00022981},
	{.symbol = _LoadFile_string, .addr = 0x00024f5d},
	{.symbol = _LoadMatchedBundles_string, .addr = 0x000277c1},
	{.symbol = _LoadMatchedModules_string, .addr = 0x000220e3},
	{.symbol = _LoadThinFatFile_string, .addr = 0x000253d3},
	{.symbol = _LoadVolumeFile_string, .addr = 0x00024c02},
	{.symbol = _MD5Final_string, .addr = 0x0002ee01},
	{.symbol = _MD5Init_string, .addr = 0x0002e648},
	{.symbol = _MD5Update_string, .addr = 0x0002ed1d},
	{.symbol = _MSDOSFree_string, .addr = 0x000317d5},
	{.symbol = _MSDOSGetDescription_string, .addr = 0x00032a1e},
	{.symbol = _MSDOSGetDirEntry_string, .addr = 0x00032590},
	{.symbol = _MSDOSGetFileBlock_string, .addr = 0x000328a7},
	{.symbol = _MSDOSGetUUID_string, .addr = 0x00032209},
	{.symbol = _MSDOSInitPartition_string, .addr = 0x00032033},
	{.symbol = _MSDOSLoadFile_string, .addr = 0x000324ce},
	{.symbol = _MSDOSProbe_string, .addr = 0x000324f1},
	{.symbol = _MSDOSReadFile_string, .addr = 0x0003229f},
	{.symbol = _MatchBundlesLibraries_string, .addr = 0x00026809},
	{.symbol = _MatchLibraries_string, .addr = 0x00022049},
	{.symbol = _NTFSGetDescription_string, .addr = 0x00032caa},
	{.symbol = _NTFSGetUUID_string, .addr = 0x00032c04},
	{.symbol = _NTFSProbe_string, .addr = 0x00032bd3},
	{.symbol = _OpenBSDGetDescription_string, .addr = 0x00032f9a},
	{.symbol = _OpenBSDProbe_string, .addr = 0x00032f81},
	{.symbol = _ParseXMLFile_string, .addr = 0x0002b18f},
	{.symbol = _Register_Acpi_Efi_string, .addr = 0x0002afd3},
	{.symbol = _Register_Smbios_Efi_string, .addr = 0x0002a109},
	{.symbol = _SetgPlatformName_string, .addr = 0x0002561e},
	{.symbol = _SetgRootDevice_string, .addr = 0x00025604},
	{.symbol = _Setgboardproduct_string, .addr = 0x00025611},
	{.symbol = _ThinFatFile_string, .addr = 0x0002cf3a},
	{.symbol = _XMLCastArray_string, .addr = 0x0002d184},
	{.symbol = _XMLCastBoolean_string, .addr = 0x0002d1f1},
	{.symbol = _XMLCastDict_string, .addr = 0x0002d19d},
	{.symbol = _XMLCastInteger_string, .addr = 0x0002d207},
	{.symbol = _XMLCastString_string, .addr = 0x0002d1b6},
	{.symbol = _XMLCastStringOffset_string, .addr = 0x0002d1d3},
	{.symbol = _XMLDecode_string, .addr = 0x0002d657},
	{.symbol = _XMLFreeTag_string, .addr = 0x0002d22c},
	{.symbol = _XMLGetElement_string, .addr = 0x0002d08a},
	{.symbol = _XMLGetProperty_string, .addr = 0x0002d33c},
	{.symbol = _XMLIsType_string, .addr = 0x0002d169},
	{.symbol = _XMLParseFile_string, .addr = 0x0002e0a2},
	{.symbol = _XMLParseNextTag_string, .addr = 0x0002d94c},
	{.symbol = _XMLTagCount_string, .addr = 0x0002cff0},
	{.symbol = __DATA__bss__begin_string, .addr = 0x0003aba0},
	{.symbol = __DATA__bss__end_string, .addr = 0x0003c4c4},
	{.symbol = __DATA__common__begin_string, .addr = 0x0003c4d0},
	{.symbol = __DATA__common__end_string, .addr = 0x0003c700},
	{.symbol = ___bzero_string, .addr = 0x00034d40},
	{.symbol = ___convertImage_string, .addr = 0x00021f27},
	{.symbol = ___decodeRLE_string, .addr = 0x00021815},
	{.symbol = ___divdi3_string, .addr = 0x00036302},
	{.symbol = ___doprnt_string, .addr = 0x000353d3},
	{.symbol = ___drawColorRectangle_string, .addr = 0x00021ddd},
	{.symbol = ___drawDataRectangle_string, .addr = 0x00021769},
	{.symbol = ___getNumberArrayFromProperty_string, .addr = 0x000216fc},
	{.symbol = ___getVESAModeWithProperties_string, .addr = 0x00021862},
	{.symbol = ___moddi3_string, .addr = 0x00036370},
	{.symbol = ___qdivrem_string, .addr = 0x000363e1},
	{.symbol = ___setVESAGraphicsMode_string, .addr = 0x00021ac3},
	{.symbol = ___setVideoMode_string, .addr = 0x00021c1c},
	{.symbol = ___udivdi3_string, .addr = 0x000361ce},
	{.symbol = ___umoddi3_string, .addr = 0x000361e6},
	{.symbol = __bp_string, .addr = 0x000203aa},
	{.symbol = __doprnt_truncates_string, .addr = 0x0003ab9c},
	{.symbol = __hi_malloc_string, .addr = 0x0002479d},
	{.symbol = __hi_strdup_string, .addr = 0x000247ae},
	{.symbol = __prot_to_real_string, .addr = 0x0002032d},
	{.symbol = __real_to_prot_string, .addr = 0x000202df},
	{.symbol = __sp_string, .addr = 0x000203a7},
	{.symbol = __switch_stack_string, .addr = 0x000203ad},
	{.symbol = _addBootArg_string, .addr = 0x00023942},
	{.symbol = _addConfigurationTable_string, .addr = 0x0002a37a},
	{.symbol = _add_symbol_string, .addr = 0x00026aed},
	{.symbol = _adler32_string, .addr = 0x00034a7a},
	{.symbol = _arc4_init_string, .addr = 0x00027aab},
	{.symbol = _arc4random_string, .addr = 0x00027ce4},
	{.symbol = _arc4random_addrandom_string, .addr = 0x00027bb3},
	{.symbol = _arc4random_buf_string, .addr = 0x00027c41},
	{.symbol = _arc4random_stir_string, .addr = 0x00027baa},
	{.symbol = _arc4random_uniform_string, .addr = 0x00027e54},
	{.symbol = _atoi_string, .addr = 0x000349cb},
	{.symbol = _bcopy_string, .addr = 0x000352d1},
	{.symbol = _bcopy16_string, .addr = 0x000352b1},
	{.symbol = _bcopy_no_overwrite_string, .addr = 0x000352a2},
	{.symbol = _bgetc_string, .addr = 0x0002c939},
	{.symbol = _bind_location_string, .addr = 0x000266a7},
	{.symbol = _bind_macho_string, .addr = 0x0002722f},
	{.symbol = _bios_string, .addr = 0x000203dd},
	{.symbol = _biosDevIsCDROM_string, .addr = 0x00027fac},
	{.symbol = _biosread_string, .addr = 0x0002c3ea},
	{.symbol = _boot_string, .addr = 0x000216c3},
	{.symbol = _bootArgs_string, .addr = 0x0003a6ec},
	{.symbol = _bootArgsLegacy_string, .addr = 0x0003a6e8},
	{.symbol = _bootInfo_string, .addr = 0x0003a6f0},
	{.symbol = _bsearch_string, .addr = 0x00034b18},
	{.symbol = _build_pci_dt_string, .addr = 0x0002e5c9},
	{.symbol = _bzero_string, .addr = 0x00034d40},
	{.symbol = _chainLoad_string, .addr = 0x00024aae},
	{.symbol = _chainbootdev_string, .addr = 0x000204b0},
	{.symbol = _chainbootflag_string, .addr = 0x000204b1},
	{.symbol = _clearBootArgs_string, .addr = 0x0002399f},
	{.symbol = _clearScreenRows_string, .addr = 0x0002c0ae},
	{.symbol = _close_string, .addr = 0x00024b56},
	{.symbol = _common_boot_string, .addr = 0x000209df},
	{.symbol = _continue_at_low_address_string, .addr = 0x000202b4},
	{.symbol = _convertHexStr2Binary_string, .addr = 0x0003388a},
	{.symbol = _copyArgument_string, .addr = 0x00023064},
	{.symbol = _copyMultibootInfo_string, .addr = 0x00024834},
	{.symbol = _crc32_string, .addr = 0x00036209},
	{.symbol = _debug_putc_string, .addr = 0x0002babd},
	{.symbol = _decompress_lzss_string, .addr = 0x0002e127},
	{.symbol = _delay_string, .addr = 0x0002bff6},
	{.symbol = _determine_safe_hi_addr_string, .addr = 0x0002470e},
	{.symbol = _devprop_add_device_string, .addr = 0x00033fa1},
	{.symbol = _devprop_add_value_string, .addr = 0x00033d65},
	{.symbol = _devprop_create_string_string, .addr = 0x00033d30},
	{.symbol = _devprop_free_string_string, .addr = 0x00033ab6},
	{.symbol = _devprop_generate_string_string, .addr = 0x00033b1e},
	{.symbol = _devprop_make_device_string, .addr = 0x00033e9f},
	{.symbol = _diskFreeMap_string, .addr = 0x0002802b},
	{.symbol = _diskIsCDROM_string, .addr = 0x00027fd0},
	{.symbol = _diskRead_string, .addr = 0x00028b01},
	{.symbol = _diskResetBootVolumes_string, .addr = 0x000285bd},
	{.symbol = _diskScanBootVolumes_string, .addr = 0x00028e1b},
	{.symbol = _diskSeek_string, .addr = 0x00027eae},
	{.symbol = _dump_pci_dt_string, .addr = 0x0002e3d2},
	{.symbol = _ebiosEjectMedia_string, .addr = 0x0002c179},
	{.symbol = _ebiosread_string, .addr = 0x0002c317},
	{.symbol = _ebioswrite_string, .addr = 0x0002c226},
	{.symbol = _efi_guid_compare_string, .addr = 0x00036262},
	{.symbol = _efi_guid_is_null_string, .addr = 0x0003623a},
	{.symbol = _efi_guid_unparse_upper_string, .addr = 0x000362b3},
	{.symbol = _efi_inject_get_devprop_string_string, .addr = 0x00034027},
	{.symbol = _enableA20_string, .addr = 0x0002a09f},
	{.symbol = _enable_pci_devs_string, .addr = 0x0002e2d4},
	{.symbol = _ents_string, .addr = 0x00039ce0},
	{.symbol = _error_string, .addr = 0x0002bcc2},
	{.symbol = _execute_hook_string, .addr = 0x00027a37},
	{.symbol = _file_size_string, .addr = 0x0002557f},
	{.symbol = _finalizeBootStruct_string, .addr = 0x00029b08},
	{.symbol = _finalizeEFIConfigTable_string, .addr = 0x0002a174},
	{.symbol = _free_string, .addr = 0x00034ece},
	{.symbol = _freeFilteredBVChain_string, .addr = 0x00027ff7},
	{.symbol = _free_platform_env_string, .addr = 0x00025697},
	{.symbol = _gAppleBootPictRLE_string, .addr = 0x00039218},
	{.symbol = _gCompareTable_string, .addr = 0x0003c6f0},
	{.symbol = _gCompareTableCompressed_string, .addr = 0x0003aa9c},
	{.symbol = _gEfiAcpi20TableGuid_string, .addr = 0x0003a714},
	{.symbol = _gEfiAcpiTableGuid_string, .addr = 0x0003a704},
	{.symbol = _gEfiConfigurationTable32_string, .addr = 0x0003c530},
	{.symbol = _gEfiConfigurationTable64_string, .addr = 0x0003c600},
	{.symbol = _gEfiConfigurationTableNode_string, .addr = 0x0003a700},
	{.symbol = _gEfiSmbiosTableGuid_string, .addr = 0x00039c60},
	{.symbol = _gLowerCaseTable_string, .addr = 0x0003c6f4},
	{.symbol = _gLowerCaseTableCompressed_string, .addr = 0x0003a7c4},
	{.symbol = _gNumTables32_string, .addr = 0x0003a724},
	{.symbol = _gNumTables64_string, .addr = 0x0003a728},
	{.symbol = _gST32_string, .addr = 0x0003a6f8},
	{.symbol = _gST64_string, .addr = 0x0003a6fc},
	{.symbol = _getBVChainForBIOSDev_string, .addr = 0x00027e8f},
	{.symbol = _getBoolForKey_string, .addr = 0x0002b897},
	{.symbol = _getBootArgs_string, .addr = 0x00029afe},
	{.symbol = _getBootOptions_string, .addr = 0x00023a61},
	{.symbol = _getBootVolumeDescription_string, .addr = 0x0002825b},
	{.symbol = _getBootVolumeRef_string, .addr = 0x00024e18},
	{.symbol = _getBvChain_string, .addr = 0x00020540},
	{.symbol = _getConventionalMemorySize_string, .addr = 0x0002c4c3},
	{.symbol = _getCursorPositionAndType_string, .addr = 0x0002c0d1},
	{.symbol = _getDeviceDescription_string, .addr = 0x00024ba0},
	{.symbol = _getExtendedMemorySize_string, .addr = 0x0002c4e3},
	{.symbol = _getIntForKey_string, .addr = 0x0002b7ad},
	{.symbol = _getKernelCachePath_string, .addr = 0x000205fb},
	{.symbol = _getMemoryInfoString_string, .addr = 0x00023847},
	{.symbol = _getMemoryMap_string, .addr = 0x0002c7a6},
	{.symbol = _getNextArg_string, .addr = 0x0002b0dc},
	{.symbol = _getPciRootUID_string, .addr = 0x0002e303},
	{.symbol = _getPlatformName_string, .addr = 0x0002a087},
	{.symbol = _getSmbiosOriginal_string, .addr = 0x0002bdce},
	{.symbol = _getStringForKey_string, .addr = 0x0002b93d},
	{.symbol = _getStringFromUUID_string, .addr = 0x00033a3d},
	{.symbol = _getUUIDFromString_string, .addr = 0x0003396a},
	{.symbol = _getVBEInfo_string, .addr = 0x0002cafe},
	{.symbol = _getVBEModeInfo_string, .addr = 0x0002cab4},
	{.symbol = _getValueForBootKey_string, .addr = 0x0002b514},
	{.symbol = _getValueForConfigTableKey_string, .addr = 0x0002b5bb},
	{.symbol = _getValueForKey_string, .addr = 0x0002b670},
	{.symbol = _getVideoMode_string, .addr = 0x00029a93},
	{.symbol = _getVolumeLabelAlias_string, .addr = 0x00028172},
	{.symbol = _get_callback_string, .addr = 0x000267db},
	{.symbol = _get_drive_info_string, .addr = 0x0002c669},
	{.symbol = _get_env_string, .addr = 0x00025c8b},
	{.symbol = _get_env_ptr_string, .addr = 0x00025c19},
	{.symbol = _get_env_var_string, .addr = 0x00025c4e},
	{.symbol = _get_num_tables_string, .addr = 0x000334de},
	{.symbol = _get_num_tables64_string, .addr = 0x000334ef},
	{.symbol = _getc_string, .addr = 0x0002bb85},
	{.symbol = _getchar_string, .addr = 0x0002bd91},
	{.symbol = _gettimeofday_string, .addr = 0x0002fbc9},
	{.symbol = _halt_string, .addr = 0x00020383},
	{.symbol = _handle_symtable_string, .addr = 0x000270d4},
	{.symbol = _hi_multiboot_string, .addr = 0x0002496a},
	{.symbol = _initBooterLog_string, .addr = 0x0002bc3c},
	{.symbol = _initKernBootStruct_string, .addr = 0x00029f05},
	{.symbol = _init_ut_fnc_string, .addr = 0x0002bdc9},
	{.symbol = _initialize_runtime_string, .addr = 0x00021681},
	{.symbol = _iob_from_fdesc_string, .addr = 0x00024b33},
	{.symbol = _is_no_emulation_string, .addr = 0x0002c5ea},
	{.symbol = _jump_to_chainbooter_string, .addr = 0x000202ca},
	{.symbol = _loadBooterConfig_string, .addr = 0x0002b383},
	{.symbol = _loadConfigFile_string, .addr = 0x0002b444},
	{.symbol = _loadOverrideConfig_string, .addr = 0x0002b2d3},
	{.symbol = _loadSystemConfig_string, .addr = 0x0002b21e},
	{.symbol = _localVPrintf_string, .addr = 0x0002bb25},
	{.symbol = _longjmp_string, .addr = 0x000361b0},
	{.symbol = _lookup_all_symbols_string, .addr = 0x00026756},
	{.symbol = _lookup_symbol_string, .addr = 0x0003a5d0},
	{.symbol = _lspci_string, .addr = 0x0002371c},
	{.symbol = _malloc_string, .addr = 0x0003522b},
	{.symbol = _malloc_init_string, .addr = 0x00034d62},
	{.symbol = _matchVolumeToString_string, .addr = 0x0002805d},
	{.symbol = _memcmp_string, .addr = 0x00034ae5},
	{.symbol = _memcpy_string, .addr = 0x00035280},
	{.symbol = _memmove_string, .addr = 0x00034ba2},
	{.symbol = _memset_string, .addr = 0x00034d13},
	{.symbol = _moduleCallbacks_string, .addr = 0x0003a5c8},
	{.symbol = _moduleSymbols_string, .addr = 0x0003a5cc},
	{.symbol = _msglog_string, .addr = 0x0002bd61},
	{.symbol = _multiboot_to_boot_string, .addr = 0x00024af3},
	{.symbol = _newEmptyStringWithLength_string, .addr = 0x0002baa4},
	{.symbol = _newFilteredBVChain_string, .addr = 0x00028377},
	{.symbol = _newGPTBVRef_string, .addr = 0x00028c05},
	{.symbol = _newString_string, .addr = 0x0002ba79},
	{.symbol = _newStringForKey_string, .addr = 0x0002b9ce},
	{.symbol = _newStringWithFormat_string, .addr = 0x0002bb3a},
	{.symbol = _newStringWithLength_string, .addr = 0x0002b177},
	{.symbol = _open_string, .addr = 0x000250d0},
	{.symbol = _open_bvdev_string, .addr = 0x000250f9},
	{.symbol = _parse_mach_string, .addr = 0x0002757c},
	{.symbol = _pause_string, .addr = 0x0002bd7d},
	{.symbol = _pci_config_read16_string, .addr = 0x0002e262},
	{.symbol = _pci_config_read32_string, .addr = 0x0002e28d},
	{.symbol = _pci_config_read8_string, .addr = 0x0002e238},
	{.symbol = _pci_config_write16_string, .addr = 0x0002e2a5},
	{.symbol = _pci_config_write32_string, .addr = 0x0002e5ae},
	{.symbol = _pci_config_write8_string, .addr = 0x0002e580},
	{.symbol = _platform_env_string, .addr = 0x0003a5b4},
	{.symbol = _prf_string, .addr = 0x00035e50},
	{.symbol = _printMemoryInfo_string, .addr = 0x00023776},
	{.symbol = _printf_string, .addr = 0x0002bc21},
	{.symbol = _processBootOptions_string, .addr = 0x000230eb},
	{.symbol = _promptForRescanOption_string, .addr = 0x00022d6f},
	{.symbol = _putc_string, .addr = 0x0002c1ef},
	{.symbol = _putca_string, .addr = 0x0002c1af},
	{.symbol = _putchar_string, .addr = 0x0002bb9c},
	{.symbol = _re_set_env_string, .addr = 0x00025bdc},
	{.symbol = _re_set_env_copy_string, .addr = 0x000263e2},
	{.symbol = _read_string, .addr = 0x000254c1},
	{.symbol = _readBootSector_string, .addr = 0x00028ba8},
	{.symbol = _readDefaultPlatformName_string, .addr = 0x0002bf7c},
	{.symbol = _readKeyboardShiftFlags_string, .addr = 0x0002c590},
	{.symbol = _readKeyboardStatus_string, .addr = 0x0002c5b7},
	{.symbol = _readSMBIOS_string, .addr = 0x0002be5b},
	{.symbol = _realloc_string, .addr = 0x0003523f},
	{.symbol = _reallyVPrint_string, .addr = 0x0002bae4},
	{.symbol = _rebase_location_string, .addr = 0x00026691},
	{.symbol = _rebase_macho_string, .addr = 0x00026422},
	{.symbol = _register_hook_callback_string, .addr = 0x0002799f},
	{.symbol = _replace_function_string, .addr = 0x00026a80},
	{.symbol = _replace_function_any_string, .addr = 0x00026ac6},
	{.symbol = _replace_system_function_string, .addr = 0x00026ad8},
	{.symbol = _rescanBIOSDevice_string, .addr = 0x00028624},
	{.symbol = _reserveKernBootStruct_string, .addr = 0x00029ed8},
	{.symbol = _reserveKernLegacyBootStruct_string, .addr = 0x00029d15},
	{.symbol = _resolveConfig_string, .addr = 0x0002b07a},
	{.symbol = _root_pci_dev_string, .addr = 0x0003c4d0},
	{.symbol = _rtc_read_clock_string, .addr = 0x000340f9},
	{.symbol = _safe_set_env_string, .addr = 0x000263a4},
	{.symbol = _safe_set_env_copy_string, .addr = 0x000263cb},
	{.symbol = _scanBootVolumes_string, .addr = 0x00024d66},
	{.symbol = _scanDisks_string, .addr = 0x00024f89},
	{.symbol = _scan_cpu_string, .addr = 0x0002ee6f},
	{.symbol = _scan_pci_bus_string, .addr = 0x0002e457},
	{.symbol = _scan_platform_string, .addr = 0x00025649},
	{.symbol = _scollPage_string, .addr = 0x0002c055},
	{.symbol = _selectBootVolume_string, .addr = 0x00024c32},
	{.symbol = _setActiveDisplayPage_string, .addr = 0x0002c02c},
	{.symbol = _setBootArgsVideoMode_string, .addr = 0x00029a80},
	{.symbol = _setBootArgsVideoStruct_string, .addr = 0x00029aa3},
	{.symbol = _setBootGlobals_string, .addr = 0x000255a5},
	{.symbol = _setCursorPosition_string, .addr = 0x0002c140},
	{.symbol = _setCursorType_string, .addr = 0x0002c116},
	{.symbol = _setRootVolume_string, .addr = 0x00024b80},
	{.symbol = _setVBEMode_string, .addr = 0x0002ca66},
	{.symbol = _setVBEPalette_string, .addr = 0x0002ca0c},
	{.symbol = _set_env_string, .addr = 0x00026298},
	{.symbol = _set_env_copy_string, .addr = 0x00026281},
	{.symbol = _setjmp_string, .addr = 0x00036196},
	{.symbol = _setupBooterLog_string, .addr = 0x0002bbdb},
	{.symbol = _setupDeviceProperties_string, .addr = 0x00034056},
	{.symbol = _setupFakeEfi_string, .addr = 0x0002a55b},
	{.symbol = _setupSmbiosConfigFile_string, .addr = 0x0002a295},
	{.symbol = _setup_acpi_string, .addr = 0x0002a4b6},
	{.symbol = _setup_pci_devs_string, .addr = 0x0002e422},
	{.symbol = _showError_string, .addr = 0x00025657},
	{.symbol = _showHelp_string, .addr = 0x00022f90},
	{.symbol = _showMessage_string, .addr = 0x00022f74},
	{.symbol = _showTextBuffer_string, .addr = 0x00022d8d},
	{.symbol = _showTextFile_string, .addr = 0x00022edc},
	{.symbol = _sleep_string, .addr = 0x0002c98f},
	{.symbol = _snprintf_string, .addr = 0x00035ea0},
	{.symbol = _sprintf_string, .addr = 0x00035e6a},
	{.symbol = _startprog_string, .addr = 0x0002038d},
	{.symbol = _stop_string, .addr = 0x0002bc8d},
	{.symbol = _strbreak_string, .addr = 0x00034bbc},
	{.symbol = _strcat_string, .addr = 0x00034a3b},
	{.symbol = _strchr_string, .addr = 0x00034a5b},
	{.symbol = _strcmp_string, .addr = 0x000348b2},
	{.symbol = _strcpy_string, .addr = 0x00034910},
	{.symbol = _strdup_string, .addr = 0x00034b5c},
	{.symbol = _strlcat_string, .addr = 0x00034c4f},
	{.symbol = _strlcpy_string, .addr = 0x00034986},
	{.symbol = _strlen_string, .addr = 0x00034a21},
	{.symbol = _strncat_string, .addr = 0x000349ef},
	{.symbol = _strncmp_string, .addr = 0x000348db},
	{.symbol = _strncpy_string, .addr = 0x00034928},
	{.symbol = _strstr_string, .addr = 0x00034cac},
	{.symbol = _strtol_string, .addr = 0x00035ee5},
	{.symbol = _strtoul_string, .addr = 0x00036046},
	{.symbol = _testBiosread_string, .addr = 0x00029a6e},
	{.symbol = _testFAT32EFIBootSector_string, .addr = 0x00028b30},
	{.symbol = _textAddress_string, .addr = 0x0003a5b8},
	{.symbol = _textSection_string, .addr = 0x0003a5c0},
	{.symbol = _time18_string, .addr = 0x0002c556},
	{.symbol = _unset_env_string, .addr = 0x00025bc5},
	{.symbol = _uterror_string, .addr = 0x0003c4e0},
	{.symbol = _utf_decodestr_string, .addr = 0x00034557},
	{.symbol = _utf_encodestr_string, .addr = 0x00034632},
	{.symbol = _verbose_string, .addr = 0x0002bd2a},
	{.symbol = _video_mode_string, .addr = 0x0002c49a},
	{.symbol = _vsnprintf_string, .addr = 0x00035e13},
	{.symbol = _waitThenReload_string, .addr = 0x000247d6},
	{.symbol = _write_string, .addr = 0x00025520},
	{.symbol = _zalloced_size_string, .addr = 0x0003c6f8},
	{.symbol = _zout_string, .addr = 0x0003c6fc},
	{.symbol = boot2_string, .addr = 0x00020200},
};
