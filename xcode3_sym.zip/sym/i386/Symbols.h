typedef struct {
	char*	symbol;
	unsigned int	addr;
} symbol_t;

static char _AllocateKernelMemory_string[] = "_AllocateKernelMemory";
static char _AllocateMemoryRange_string[] = "_AllocateMemoryRange";
static char _BeFSGetDescription_string[] = "_BeFSGetDescription";
static char _BeFSProbe_string[] = "_BeFSProbe";
static char _BinaryUnicodeCompare_string[] = "_BinaryUnicodeCompare";
static char _CacheInit_string[] = "_CacheInit";
static char _CacheRead_string[] = "_CacheRead";
static char _CacheReset_string[] = "_CacheReset";
static char _CreateUUIDString_string[] = "_CreateUUIDString";
static char _DT__AddChild_string[] = "_DT__AddChild";
static char _DT__AddProperty_string[] = "_DT__AddProperty";
static char _DT__Finalize_string[] = "_DT__Finalize";
static char _DT__FindNode_string[] = "_DT__FindNode";
static char _DT__FlattenDeviceTree_string[] = "_DT__FlattenDeviceTree";
static char _DT__FreeNode_string[] = "_DT__FreeNode";
static char _DT__FreeProperty_string[] = "_DT__FreeProperty";
static char _DT__GetName_string[] = "_DT__GetName";
static char _DT__Initialize_string[] = "_DT__Initialize";
static char _DecodeKernel_string[] = "_DecodeKernel";
static char _DecodeMachO_string[] = "_DecodeMachO";
static char _EX2GetDescription_string[] = "_EX2GetDescription";
static char _EX2Probe_string[] = "_EX2Probe";
static char _EXFATGetDescription_string[] = "_EXFATGetDescription";
static char _EXFATGetUUID_string[] = "_EXFATGetUUID";
static char _EXFATProbe_string[] = "_EXFATProbe";
static char _FastRelString_string[] = "_FastRelString";
static char _FastUnicodeCompare_string[] = "_FastUnicodeCompare";
static char _FileLoadBundles_string[] = "_FileLoadBundles";
static char _FileLoadDrivers_string[] = "_FileLoadDrivers";
static char _FindAcpiTables_string[] = "_FindAcpiTables";
static char _FreeBSDGetDescription_string[] = "_FreeBSDGetDescription";
static char _FreeBSDProbe_string[] = "_FreeBSDProbe";
static char _GPT_BASICDATA2_GUID_string[] = "_GPT_BASICDATA2_GUID";
static char _GPT_BASICDATA_GUID_string[] = "_GPT_BASICDATA_GUID";
static char _GPT_BOOT_GUID_string[] = "_GPT_BOOT_GUID";
static char _GPT_EFISYS_GUID_string[] = "_GPT_EFISYS_GUID";
static char _GPT_HFS_GUID_string[] = "_GPT_HFS_GUID";
static char _Gdt_string[] = "_Gdt";
static char _Gdtr_string[] = "_Gdtr";
static char _GetBundleDict_string[] = "_GetBundleDict";
static char _GetBundlePath_string[] = "_GetBundlePath";
static char _GetBundlePersonality_string[] = "_GetBundlePersonality";
static char _GetChecksum_string[] = "_GetChecksum";
static char _GetDirEntry_string[] = "_GetDirEntry";
static char _GetFileInfo_string[] = "_GetFileInfo";
static char _GetgPlatformName_string[] = "_GetgPlatformName";
static char _GetgRootDevice_string[] = "_GetgRootDevice";
static char _Getgboardproduct_string[] = "_Getgboardproduct";
static char _HFSFree_string[] = "_HFSFree";
static char _HFSGetDescription_string[] = "_HFSGetDescription";
static char _HFSGetDirEntry_string[] = "_HFSGetDirEntry";
static char _HFSGetFileBlock_string[] = "_HFSGetFileBlock";
static char _HFSGetUUID_string[] = "_HFSGetUUID";
static char _HFSInitPartition_string[] = "_HFSInitPartition";
static char _HFSLoadFile_string[] = "_HFSLoadFile";
static char _HFSProbe_string[] = "_HFSProbe";
static char _HFSReadFile_string[] = "_HFSReadFile";
static char _Idtr_prot_string[] = "_Idtr_prot";
static char _Idtr_real_string[] = "_Idtr_real";
static char _InitBootPrompt_string[] = "_InitBootPrompt";
static char _InitBundleSupport_string[] = "_InitBundleSupport";
static char _InitDriverSupport_string[] = "_InitDriverSupport";
static char _LoadBundlePList_string[] = "_LoadBundlePList";
static char _LoadBundles_string[] = "_LoadBundles";
static char _LoadDriverMKext_string[] = "_LoadDriverMKext";
static char _LoadDriverPList_string[] = "_LoadDriverPList";
static char _LoadDrivers_string[] = "_LoadDrivers";
static char _LoadFile_string[] = "_LoadFile";
static char _LoadMatchedBundles_string[] = "_LoadMatchedBundles";
static char _LoadMatchedModules_string[] = "_LoadMatchedModules";
static char _LoadThinFatFile_string[] = "_LoadThinFatFile";
static char _LoadVolumeFile_string[] = "_LoadVolumeFile";
static char _MD5Final_string[] = "_MD5Final";
static char _MD5Init_string[] = "_MD5Init";
static char _MD5Update_string[] = "_MD5Update";
static char _MSDOSFree_string[] = "_MSDOSFree";
static char _MSDOSGetDescription_string[] = "_MSDOSGetDescription";
static char _MSDOSGetDirEntry_string[] = "_MSDOSGetDirEntry";
static char _MSDOSGetFileBlock_string[] = "_MSDOSGetFileBlock";
static char _MSDOSGetUUID_string[] = "_MSDOSGetUUID";
static char _MSDOSInitPartition_string[] = "_MSDOSInitPartition";
static char _MSDOSLoadFile_string[] = "_MSDOSLoadFile";
static char _MSDOSProbe_string[] = "_MSDOSProbe";
static char _MSDOSReadFile_string[] = "_MSDOSReadFile";
static char _MatchBundlesLibraries_string[] = "_MatchBundlesLibraries";
static char _MatchLibraries_string[] = "_MatchLibraries";
static char _NTFSGetDescription_string[] = "_NTFSGetDescription";
static char _NTFSGetUUID_string[] = "_NTFSGetUUID";
static char _NTFSProbe_string[] = "_NTFSProbe";
static char _OpenBSDGetDescription_string[] = "_OpenBSDGetDescription";
static char _OpenBSDProbe_string[] = "_OpenBSDProbe";
static char _ParseXMLFile_string[] = "_ParseXMLFile";
static char _Register_Acpi_Efi_string[] = "_Register_Acpi_Efi";
static char _Register_Smbios_Efi_string[] = "_Register_Smbios_Efi";
static char _SetgPlatformName_string[] = "_SetgPlatformName";
static char _SetgRootDevice_string[] = "_SetgRootDevice";
static char _Setgboardproduct_string[] = "_Setgboardproduct";
static char _ThinFatFile_string[] = "_ThinFatFile";
static char _XMLCastArray_string[] = "_XMLCastArray";
static char _XMLCastBoolean_string[] = "_XMLCastBoolean";
static char _XMLCastDict_string[] = "_XMLCastDict";
static char _XMLCastInteger_string[] = "_XMLCastInteger";
static char _XMLCastString_string[] = "_XMLCastString";
static char _XMLCastStringOffset_string[] = "_XMLCastStringOffset";
static char _XMLDecode_string[] = "_XMLDecode";
static char _XMLFreeTag_string[] = "_XMLFreeTag";
static char _XMLGetElement_string[] = "_XMLGetElement";
static char _XMLGetProperty_string[] = "_XMLGetProperty";
static char _XMLIsType_string[] = "_XMLIsType";
static char _XMLParseFile_string[] = "_XMLParseFile";
static char _XMLParseNextTag_string[] = "_XMLParseNextTag";
static char _XMLTagCount_string[] = "_XMLTagCount";
static char __DATA__bss__begin_string[] = "__DATA__bss__begin";
static char __DATA__bss__end_string[] = "__DATA__bss__end";
static char __DATA__common__begin_string[] = "__DATA__common__begin";
static char __DATA__common__end_string[] = "__DATA__common__end";
static char ___bzero_string[] = "___bzero";
static char ___convertImage_string[] = "___convertImage";
static char ___decodeRLE_string[] = "___decodeRLE";
static char ___divdi3_string[] = "___divdi3";
static char ___doprnt_string[] = "___doprnt";
static char ___drawColorRectangle_string[] = "___drawColorRectangle";
static char ___drawDataRectangle_string[] = "___drawDataRectangle";
static char ___getNumberArrayFromProperty_string[] = "___getNumberArrayFromProperty";
static char ___getVESAModeWithProperties_string[] = "___getVESAModeWithProperties";
static char ___moddi3_string[] = "___moddi3";
static char ___qdivrem_string[] = "___qdivrem";
static char ___setVESAGraphicsMode_string[] = "___setVESAGraphicsMode";
static char ___setVideoMode_string[] = "___setVideoMode";
static char ___udivdi3_string[] = "___udivdi3";
static char ___umoddi3_string[] = "___umoddi3";
static char __bp_string[] = "__bp";
static char __doprnt_truncates_string[] = "__doprnt_truncates";
static char __hi_malloc_string[] = "__hi_malloc";
static char __hi_strdup_string[] = "__hi_strdup";
static char __prot_to_real_string[] = "__prot_to_real";
static char __real_to_prot_string[] = "__real_to_prot";
static char __sp_string[] = "__sp";
static char __switch_stack_string[] = "__switch_stack";
static char _addBootArg_string[] = "_addBootArg";
static char _addConfigurationTable_string[] = "_addConfigurationTable";
static char _add_symbol_string[] = "_add_symbol";
static char _adler32_string[] = "_adler32";
static char _arc4_init_string[] = "_arc4_init";
static char _arc4random_string[] = "_arc4random";
static char _arc4random_addrandom_string[] = "_arc4random_addrandom";
static char _arc4random_buf_string[] = "_arc4random_buf";
static char _arc4random_stir_string[] = "_arc4random_stir";
static char _arc4random_uniform_string[] = "_arc4random_uniform";
static char _atoi_string[] = "_atoi";
static char _bcopy_string[] = "_bcopy";
static char _bcopy16_string[] = "_bcopy16";
static char _bcopy_no_overwrite_string[] = "_bcopy_no_overwrite";
static char _bgetc_string[] = "_bgetc";
static char _bind_location_string[] = "_bind_location";
static char _bind_macho_string[] = "_bind_macho";
static char _bios_string[] = "_bios";
static char _biosDevIsCDROM_string[] = "_biosDevIsCDROM";
static char _biosread_string[] = "_biosread";
static char _boot_string[] = "_boot";
static char _bootArgs_string[] = "_bootArgs";
static char _bootArgsLegacy_string[] = "_bootArgsLegacy";
static char _bootInfo_string[] = "_bootInfo";
static char _bsearch_string[] = "_bsearch";
static char _build_pci_dt_string[] = "_build_pci_dt";
static char _bzero_string[] = "_bzero";
static char _chainLoad_string[] = "_chainLoad";
static char _chainbootdev_string[] = "_chainbootdev";
static char _chainbootflag_string[] = "_chainbootflag";
static char _clearBootArgs_string[] = "_clearBootArgs";
static char _clearScreenRows_string[] = "_clearScreenRows";
static char _close_string[] = "_close";
static char _common_boot_string[] = "_common_boot";
static char _continue_at_low_address_string[] = "_continue_at_low_address";
static char _convertHexStr2Binary_string[] = "_convertHexStr2Binary";
static char _copyArgument_string[] = "_copyArgument";
static char _copyMultibootInfo_string[] = "_copyMultibootInfo";
static char _crc32_string[] = "_crc32";
static char _debug_putc_string[] = "_debug_putc";
static char _decompress_lzss_string[] = "_decompress_lzss";
static char _delay_string[] = "_delay";
static char _determine_safe_hi_addr_string[] = "_determine_safe_hi_addr";
static char _devprop_add_device_string[] = "_devprop_add_device";
static char _devprop_add_value_string[] = "_devprop_add_value";
static char _devprop_create_string_string[] = "_devprop_create_string";
static char _devprop_free_string_string[] = "_devprop_free_string";
static char _devprop_generate_string_string[] = "_devprop_generate_string";
static char _devprop_make_device_string[] = "_devprop_make_device";
static char _diskFreeMap_string[] = "_diskFreeMap";
static char _diskIsCDROM_string[] = "_diskIsCDROM";
static char _diskRead_string[] = "_diskRead";
static char _diskResetBootVolumes_string[] = "_diskResetBootVolumes";
static char _diskScanBootVolumes_string[] = "_diskScanBootVolumes";
static char _diskSeek_string[] = "_diskSeek";
static char _dump_pci_dt_string[] = "_dump_pci_dt";
static char _ebiosEjectMedia_string[] = "_ebiosEjectMedia";
static char _ebiosread_string[] = "_ebiosread";
static char _ebioswrite_string[] = "_ebioswrite";
static char _efi_guid_compare_string[] = "_efi_guid_compare";
static char _efi_guid_is_null_string[] = "_efi_guid_is_null";
static char _efi_guid_unparse_upper_string[] = "_efi_guid_unparse_upper";
static char _efi_inject_get_devprop_string_string[] = "_efi_inject_get_devprop_string";
static char _enableA20_string[] = "_enableA20";
static char _enable_pci_devs_string[] = "_enable_pci_devs";
static char _error_string[] = "_error";
static char _execute_hook_string[] = "_execute_hook";
static char _file_size_string[] = "_file_size";
static char _finalizeBootStruct_string[] = "_finalizeBootStruct";
static char _finalizeEFIConfigTable_string[] = "_finalizeEFIConfigTable";
static char _free_string[] = "_free";
static char _freeFilteredBVChain_string[] = "_freeFilteredBVChain";
static char _free_platform_env_string[] = "_free_platform_env";
static char _gAppleBootPictRLE_string[] = "_gAppleBootPictRLE";
static char _gCompareTable_string[] = "_gCompareTable";
static char _gCompareTableCompressed_string[] = "_gCompareTableCompressed";
static char _gEfiAcpi20TableGuid_string[] = "_gEfiAcpi20TableGuid";
static char _gEfiAcpiTableGuid_string[] = "_gEfiAcpiTableGuid";
static char _gEfiConfigurationTable32_string[] = "_gEfiConfigurationTable32";
static char _gEfiConfigurationTable64_string[] = "_gEfiConfigurationTable64";
static char _gEfiConfigurationTableNode_string[] = "_gEfiConfigurationTableNode";
static char _gEfiSmbiosTableGuid_string[] = "_gEfiSmbiosTableGuid";
static char _gLowerCaseTable_string[] = "_gLowerCaseTable";
static char _gLowerCaseTableCompressed_string[] = "_gLowerCaseTableCompressed";
static char _gNumTables32_string[] = "_gNumTables32";
static char _gNumTables64_string[] = "_gNumTables64";
static char _gST32_string[] = "_gST32";
static char _gST64_string[] = "_gST64";
static char _getBVChainForBIOSDev_string[] = "_getBVChainForBIOSDev";
static char _getBoolForKey_string[] = "_getBoolForKey";
static char _getBootArgs_string[] = "_getBootArgs";
static char _getBootOptions_string[] = "_getBootOptions";
static char _getBootVolumeDescription_string[] = "_getBootVolumeDescription";
static char _getBootVolumeRef_string[] = "_getBootVolumeRef";
static char _getBvChain_string[] = "_getBvChain";
static char _getConventionalMemorySize_string[] = "_getConventionalMemorySize";
static char _getCursorPositionAndType_string[] = "_getCursorPositionAndType";
static char _getDeviceDescription_string[] = "_getDeviceDescription";
static char _getExtendedMemorySize_string[] = "_getExtendedMemorySize";
static char _getIntForKey_string[] = "_getIntForKey";
static char _getKernelCachePath_string[] = "_getKernelCachePath";
static char _getMemoryInfoString_string[] = "_getMemoryInfoString";
static char _getMemoryMap_string[] = "_getMemoryMap";
static char _getNextArg_string[] = "_getNextArg";
static char _getPciRootUID_string[] = "_getPciRootUID";
static char _getPlatformName_string[] = "_getPlatformName";
static char _getSmbiosOriginal_string[] = "_getSmbiosOriginal";
static char _getStringForKey_string[] = "_getStringForKey";
static char _getStringFromUUID_string[] = "_getStringFromUUID";
static char _getUUIDFromString_string[] = "_getUUIDFromString";
static char _getVBEInfo_string[] = "_getVBEInfo";
static char _getVBEModeInfo_string[] = "_getVBEModeInfo";
static char _getValueForBootKey_string[] = "_getValueForBootKey";
static char _getValueForConfigTableKey_string[] = "_getValueForConfigTableKey";
static char _getValueForKey_string[] = "_getValueForKey";
static char _getVideoMode_string[] = "_getVideoMode";
static char _getVolumeLabelAlias_string[] = "_getVolumeLabelAlias";
static char _get_callback_string[] = "_get_callback";
static char _get_drive_info_string[] = "_get_drive_info";
static char _get_env_string[] = "_get_env";
static char _get_env_ptr_string[] = "_get_env_ptr";
static char _get_env_var_string[] = "_get_env_var";
static char _get_num_tables_string[] = "_get_num_tables";
static char _get_num_tables64_string[] = "_get_num_tables64";
static char _getc_string[] = "_getc";
static char _getchar_string[] = "_getchar";
static char _gettimeofday_string[] = "_gettimeofday";
static char _halt_string[] = "_halt";
static char _handle_symtable_string[] = "_handle_symtable";
static char _hi_multiboot_string[] = "_hi_multiboot";
static char _initBooterLog_string[] = "_initBooterLog";
static char _initKernBootStruct_string[] = "_initKernBootStruct";
static char _init_ut_fnc_string[] = "_init_ut_fnc";
static char _initialize_runtime_string[] = "_initialize_runtime";
static char _iob_from_fdesc_string[] = "_iob_from_fdesc";
static char _is_no_emulation_string[] = "_is_no_emulation";
static char _jump_to_chainbooter_string[] = "_jump_to_chainbooter";
static char _loadBooterConfig_string[] = "_loadBooterConfig";
static char _loadConfigFile_string[] = "_loadConfigFile";
static char _loadOverrideConfig_string[] = "_loadOverrideConfig";
static char _loadSystemConfig_string[] = "_loadSystemConfig";
static char _localVPrintf_string[] = "_localVPrintf";
static char _longjmp_string[] = "_longjmp";
static char _lookup_all_symbols_string[] = "_lookup_all_symbols";
static char _lookup_symbol_string[] = "_lookup_symbol";
static char _lspci_string[] = "_lspci";
static char _malloc_string[] = "_malloc";
static char _malloc_init_string[] = "_malloc_init";
static char _matchVolumeToString_string[] = "_matchVolumeToString";
static char _memcmp_string[] = "_memcmp";
static char _memcpy_string[] = "_memcpy";
static char _memmove_string[] = "_memmove";
static char _memset_string[] = "_memset";
static char _moduleCallbacks_string[] = "_moduleCallbacks";
static char _moduleSymbols_string[] = "_moduleSymbols";
static char _msglog_string[] = "_msglog";
static char _multiboot_to_boot_string[] = "_multiboot_to_boot";
static char _newEmptyStringWithLength_string[] = "_newEmptyStringWithLength";
static char _newFilteredBVChain_string[] = "_newFilteredBVChain";
static char _newGPTBVRef_string[] = "_newGPTBVRef";
static char _newString_string[] = "_newString";
static char _newStringForKey_string[] = "_newStringForKey";
static char _newStringWithFormat_string[] = "_newStringWithFormat";
static char _newStringWithLength_string[] = "_newStringWithLength";
static char _open_string[] = "_open";
static char _open_bvdev_string[] = "_open_bvdev";
static char _parse_mach_string[] = "_parse_mach";
static char _pause_string[] = "_pause";
static char _pci_config_read16_string[] = "_pci_config_read16";
static char _pci_config_read32_string[] = "_pci_config_read32";
static char _pci_config_read8_string[] = "_pci_config_read8";
static char _pci_config_write16_string[] = "_pci_config_write16";
static char _pci_config_write32_string[] = "_pci_config_write32";
static char _pci_config_write8_string[] = "_pci_config_write8";
static char _platform_env_string[] = "_platform_env";
static char _prf_string[] = "_prf";
static char _printMemoryInfo_string[] = "_printMemoryInfo";
static char _printf_string[] = "_printf";
static char _processBootOptions_string[] = "_processBootOptions";
static char _promptForRescanOption_string[] = "_promptForRescanOption";
static char _putc_string[] = "_putc";
static char _putca_string[] = "_putca";
static char _putchar_string[] = "_putchar";
static char _re_set_env_string[] = "_re_set_env";
static char _re_set_env_copy_string[] = "_re_set_env_copy";
static char _read_string[] = "_read";
static char _readBootSector_string[] = "_readBootSector";
static char _readDefaultPlatformName_string[] = "_readDefaultPlatformName";
static char _readKeyboardShiftFlags_string[] = "_readKeyboardShiftFlags";
static char _readKeyboardStatus_string[] = "_readKeyboardStatus";
static char _readSMBIOS_string[] = "_readSMBIOS";
static char _realloc_string[] = "_realloc";
static char _reallyVPrint_string[] = "_reallyVPrint";
static char _rebase_location_string[] = "_rebase_location";
static char _rebase_macho_string[] = "_rebase_macho";
static char _register_hook_callback_string[] = "_register_hook_callback";
static char _replace_function_string[] = "_replace_function";
static char _replace_function_any_string[] = "_replace_function_any";
static char _replace_system_function_string[] = "_replace_system_function";
static char _rescanBIOSDevice_string[] = "_rescanBIOSDevice";
static char _reserveKernBootStruct_string[] = "_reserveKernBootStruct";
static char _reserveKernLegacyBootStruct_string[] = "_reserveKernLegacyBootStruct";
static char _resolveConfig_string[] = "_resolveConfig";
static char _root_pci_dev_string[] = "_root_pci_dev";
static char _rtc_read_clock_string[] = "_rtc_read_clock";
static char _safe_set_env_string[] = "_safe_set_env";
static char _safe_set_env_copy_string[] = "_safe_set_env_copy";
static char _scanBootVolumes_string[] = "_scanBootVolumes";
static char _scanDisks_string[] = "_scanDisks";
static char _scan_cpu_string[] = "_scan_cpu";
static char _scan_pci_bus_string[] = "_scan_pci_bus";
static char _scan_platform_string[] = "_scan_platform";
static char _scollPage_string[] = "_scollPage";
static char _selectBootVolume_string[] = "_selectBootVolume";
static char _setActiveDisplayPage_string[] = "_setActiveDisplayPage";
static char _setBootArgsVideoMode_string[] = "_setBootArgsVideoMode";
static char _setBootArgsVideoStruct_string[] = "_setBootArgsVideoStruct";
static char _setBootGlobals_string[] = "_setBootGlobals";
static char _setCursorPosition_string[] = "_setCursorPosition";
static char _setCursorType_string[] = "_setCursorType";
static char _setRootVolume_string[] = "_setRootVolume";
static char _setVBEMode_string[] = "_setVBEMode";
static char _setVBEPalette_string[] = "_setVBEPalette";
static char _set_env_string[] = "_set_env";
static char _set_env_copy_string[] = "_set_env_copy";
static char _setjmp_string[] = "_setjmp";
static char _setupBooterLog_string[] = "_setupBooterLog";
static char _setupDeviceProperties_string[] = "_setupDeviceProperties";
static char _setupFakeEfi_string[] = "_setupFakeEfi";
static char _setupSmbiosConfigFile_string[] = "_setupSmbiosConfigFile";
static char _setup_acpi_string[] = "_setup_acpi";
static char _setup_pci_devs_string[] = "_setup_pci_devs";
static char _showError_string[] = "_showError";
static char _showHelp_string[] = "_showHelp";
static char _showMessage_string[] = "_showMessage";
static char _showTextBuffer_string[] = "_showTextBuffer";
static char _showTextFile_string[] = "_showTextFile";
static char _sleep_string[] = "_sleep";
static char _snprintf_string[] = "_snprintf";
static char _sprintf_string[] = "_sprintf";
static char _startprog_string[] = "_startprog";
static char _stop_string[] = "_stop";
static char _strbreak_string[] = "_strbreak";
static char _strcat_string[] = "_strcat";
static char _strchr_string[] = "_strchr";
static char _strcmp_string[] = "_strcmp";
static char _strcpy_string[] = "_strcpy";
static char _strdup_string[] = "_strdup";
static char _strlcat_string[] = "_strlcat";
static char _strlcpy_string[] = "_strlcpy";
static char _strlen_string[] = "_strlen";
static char _strncat_string[] = "_strncat";
static char _strncmp_string[] = "_strncmp";
static char _strncpy_string[] = "_strncpy";
static char _strstr_string[] = "_strstr";
static char _strtol_string[] = "_strtol";
static char _strtoul_string[] = "_strtoul";
static char _testBiosread_string[] = "_testBiosread";
static char _testFAT32EFIBootSector_string[] = "_testFAT32EFIBootSector";
static char _textAddress_string[] = "_textAddress";
static char _textSection_string[] = "_textSection";
static char _time18_string[] = "_time18";
static char _unset_env_string[] = "_unset_env";
static char _uterror_string[] = "_uterror";
static char _utf_decodestr_string[] = "_utf_decodestr";
static char _utf_encodestr_string[] = "_utf_encodestr";
static char _verbose_string[] = "_verbose";
static char _video_mode_string[] = "_video_mode";
static char _vsnprintf_string[] = "_vsnprintf";
static char _waitThenReload_string[] = "_waitThenReload";
static char _write_string[] = "_write";
static char _zalloced_size_string[] = "_zalloced_size";
static char _zout_string[] = "_zout";
static char boot2_string[] = "boot2";
symbol_t symbolList[] = {
	{.symbol = _AllocateKernelMemory_string, .addr = 0x0002c9c3},
	{.symbol = _AllocateMemoryRange_string, .addr = 0x0002ca3b},
	{.symbol = _BeFSGetDescription_string, .addr = 0x0002fa79},
	{.symbol = _BeFSProbe_string, .addr = 0x0002fa60},
	{.symbol = _BinaryUnicodeCompare_string, .addr = 0x00033f6b},
	{.symbol = _CacheInit_string, .addr = 0x0002fc54},
	{.symbol = _CacheRead_string, .addr = 0x0002fb12},
	{.symbol = _CacheReset_string, .addr = 0x0002fb03},
	{.symbol = _CreateUUIDString_string, .addr = 0x000251d9},
	{.symbol = _DT__AddChild_string, .addr = 0x00032fdc},
	{.symbol = _DT__AddProperty_string, .addr = 0x00032d7c},
	{.symbol = _DT__Finalize_string, .addr = 0x00032f3c},
	{.symbol = _DT__FindNode_string, .addr = 0x000330f9},
	{.symbol = _DT__FlattenDeviceTree_string, .addr = 0x00032ecc},
	{.symbol = _DT__FreeNode_string, .addr = 0x00032d33},
	{.symbol = _DT__FreeProperty_string, .addr = 0x00032d1d},
	{.symbol = _DT__GetName_string, .addr = 0x00032d49},
	{.symbol = _DT__Initialize_string, .addr = 0x0003309b},
	{.symbol = _DecodeKernel_string, .addr = 0x00022aba},
	{.symbol = _DecodeMachO_string, .addr = 0x0002ca85},
	{.symbol = _EX2GetDescription_string, .addr = 0x0002fd29},
	{.symbol = _EX2Probe_string, .addr = 0x0002fd10},
	{.symbol = _EXFATGetDescription_string, .addr = 0x000343f6},
	{.symbol = _EXFATGetUUID_string, .addr = 0x00034383},
	{.symbol = _EXFATProbe_string, .addr = 0x00034360},
	{.symbol = _FastRelString_string, .addr = 0x00034085},
	{.symbol = _FastUnicodeCompare_string, .addr = 0x00034105},
	{.symbol = _FileLoadBundles_string, .addr = 0x00026e76},
	{.symbol = _FileLoadDrivers_string, .addr = 0x00022665},
	{.symbol = _FindAcpiTables_string, .addr = 0x00033361},
	{.symbol = _FreeBSDGetDescription_string, .addr = 0x0002fdd6},
	{.symbol = _FreeBSDProbe_string, .addr = 0x0002fdbd},
	{.symbol = _GPT_BASICDATA2_GUID_string, .addr = 0x000397a8},
	{.symbol = _GPT_BASICDATA_GUID_string, .addr = 0x00039798},
	{.symbol = _GPT_BOOT_GUID_string, .addr = 0x00039778},
	{.symbol = _GPT_EFISYS_GUID_string, .addr = 0x00039788},
	{.symbol = _GPT_HFS_GUID_string, .addr = 0x00039768},
	{.symbol = _Gdt_string, .addr = 0x000204bc},
	{.symbol = _Gdtr_string, .addr = 0x000204f4},
	{.symbol = _GetBundleDict_string, .addr = 0x00026628},
	{.symbol = _GetBundlePath_string, .addr = 0x000265f8},
	{.symbol = _GetBundlePersonality_string, .addr = 0x00026610},
	{.symbol = _GetChecksum_string, .addr = 0x00033245},
	{.symbol = _GetDirEntry_string, .addr = 0x00024e26},
	{.symbol = _GetFileInfo_string, .addr = 0x00025114},
	{.symbol = _GetgPlatformName_string, .addr = 0x00025515},
	{.symbol = _GetgRootDevice_string, .addr = 0x00025529},
	{.symbol = _Getgboardproduct_string, .addr = 0x0002551f},
	{.symbol = _HFSFree_string, .addr = 0x00030037},
	{.symbol = _HFSGetDescription_string, .addr = 0x0003134f},
	{.symbol = _HFSGetDirEntry_string, .addr = 0x00031044},
	{.symbol = _HFSGetFileBlock_string, .addr = 0x00031401},
	{.symbol = _HFSGetUUID_string, .addr = 0x0003100f},
	{.symbol = _HFSInitPartition_string, .addr = 0x00030cc9},
	{.symbol = _HFSLoadFile_string, .addr = 0x000312fc},
	{.symbol = _HFSProbe_string, .addr = 0x0003131f},
	{.symbol = _HFSReadFile_string, .addr = 0x00031133},
	{.symbol = _Idtr_prot_string, .addr = 0x00020504},
	{.symbol = _Idtr_real_string, .addr = 0x000204fc},
	{.symbol = _InitBootPrompt_string, .addr = 0x00022c53},
	{.symbol = _InitBundleSupport_string, .addr = 0x00026a24},
	{.symbol = _InitDriverSupport_string, .addr = 0x000227cd},
	{.symbol = _LoadBundlePList_string, .addr = 0x00026b0c},
	{.symbol = _LoadBundles_string, .addr = 0x0002780e},
	{.symbol = _LoadDriverMKext_string, .addr = 0x000221e6},
	{.symbol = _LoadDriverPList_string, .addr = 0x000222a8},
	{.symbol = _LoadDrivers_string, .addr = 0x000228ce},
	{.symbol = _LoadFile_string, .addr = 0x00024e61},
	{.symbol = _LoadMatchedBundles_string, .addr = 0x0002768e},
	{.symbol = _LoadMatchedModules_string, .addr = 0x00022074},
	{.symbol = _LoadThinFatFile_string, .addr = 0x000252bd},
	{.symbol = _LoadVolumeFile_string, .addr = 0x00024b06},
	{.symbol = _MD5Final_string, .addr = 0x0002eb60},
	{.symbol = _MD5Init_string, .addr = 0x0002e3a7},
	{.symbol = _MD5Update_string, .addr = 0x0002ea7c},
	{.symbol = _MSDOSFree_string, .addr = 0x000314df},
	{.symbol = _MSDOSGetDescription_string, .addr = 0x0003271f},
	{.symbol = _MSDOSGetDirEntry_string, .addr = 0x00032291},
	{.symbol = _MSDOSGetFileBlock_string, .addr = 0x000325a8},
	{.symbol = _MSDOSGetUUID_string, .addr = 0x00031f13},
	{.symbol = _MSDOSInitPartition_string, .addr = 0x00031d3d},
	{.symbol = _MSDOSLoadFile_string, .addr = 0x000321cf},
	{.symbol = _MSDOSProbe_string, .addr = 0x000321f2},
	{.symbol = _MSDOSReadFile_string, .addr = 0x00031fa3},
	{.symbol = _MatchBundlesLibraries_string, .addr = 0x000266f3},
	{.symbol = _MatchLibraries_string, .addr = 0x00021fda},
	{.symbol = _NTFSGetDescription_string, .addr = 0x00032999},
	{.symbol = _NTFSGetUUID_string, .addr = 0x00032905},
	{.symbol = _NTFSProbe_string, .addr = 0x000328d4},
	{.symbol = _OpenBSDGetDescription_string, .addr = 0x00032c89},
	{.symbol = _OpenBSDProbe_string, .addr = 0x00032c70},
	{.symbol = _ParseXMLFile_string, .addr = 0x0002b017},
	{.symbol = _Register_Acpi_Efi_string, .addr = 0x0002ae5b},
	{.symbol = _Register_Smbios_Efi_string, .addr = 0x00029fa2},
	{.symbol = _SetgPlatformName_string, .addr = 0x00025508},
	{.symbol = _SetgRootDevice_string, .addr = 0x000254ee},
	{.symbol = _Setgboardproduct_string, .addr = 0x000254fb},
	{.symbol = _ThinFatFile_string, .addr = 0x0002cdbe},
	{.symbol = _XMLCastArray_string, .addr = 0x0002d008},
	{.symbol = _XMLCastBoolean_string, .addr = 0x0002d075},
	{.symbol = _XMLCastDict_string, .addr = 0x0002d021},
	{.symbol = _XMLCastInteger_string, .addr = 0x0002d08b},
	{.symbol = _XMLCastString_string, .addr = 0x0002d03a},
	{.symbol = _XMLCastStringOffset_string, .addr = 0x0002d057},
	{.symbol = _XMLDecode_string, .addr = 0x0002d4ce},
	{.symbol = _XMLFreeTag_string, .addr = 0x0002d0b0},
	{.symbol = _XMLGetElement_string, .addr = 0x0002cf0e},
	{.symbol = _XMLGetProperty_string, .addr = 0x0002d1b3},
	{.symbol = _XMLIsType_string, .addr = 0x0002cfed},
	{.symbol = _XMLParseFile_string, .addr = 0x0002ded4},
	{.symbol = _XMLParseNextTag_string, .addr = 0x0002d77e},
	{.symbol = _XMLTagCount_string, .addr = 0x0002ce74},
	{.symbol = __DATA__bss__begin_string, .addr = 0x0003a820},
	{.symbol = __DATA__bss__end_string, .addr = 0x0003c144},
	{.symbol = __DATA__common__begin_string, .addr = 0x0003c150},
	{.symbol = __DATA__common__end_string, .addr = 0x0003c380},
	{.symbol = ___bzero_string, .addr = 0x00034a8d},
	{.symbol = ___convertImage_string, .addr = 0x00021eb8},
	{.symbol = ___decodeRLE_string, .addr = 0x000217ab},
	{.symbol = ___divdi3_string, .addr = 0x00035fb9},
	{.symbol = ___doprnt_string, .addr = 0x00035120},
	{.symbol = ___drawColorRectangle_string, .addr = 0x00021d6e},
	{.symbol = ___drawDataRectangle_string, .addr = 0x000216ff},
	{.symbol = ___getNumberArrayFromProperty_string, .addr = 0x00021692},
	{.symbol = ___getVESAModeWithProperties_string, .addr = 0x000217f8},
	{.symbol = ___moddi3_string, .addr = 0x00036027},
	{.symbol = ___qdivrem_string, .addr = 0x00036098},
	{.symbol = ___setVESAGraphicsMode_string, .addr = 0x00021a54},
	{.symbol = ___setVideoMode_string, .addr = 0x00021bad},
	{.symbol = ___udivdi3_string, .addr = 0x00035e88},
	{.symbol = ___umoddi3_string, .addr = 0x00035ea0},
	{.symbol = __bp_string, .addr = 0x000203aa},
	{.symbol = __doprnt_truncates_string, .addr = 0x0003a81c},
	{.symbol = __hi_malloc_string, .addr = 0x000246a4},
	{.symbol = __hi_strdup_string, .addr = 0x000246b5},
	{.symbol = __prot_to_real_string, .addr = 0x0002032d},
	{.symbol = __real_to_prot_string, .addr = 0x000202df},
	{.symbol = __sp_string, .addr = 0x000203a7},
	{.symbol = __switch_stack_string, .addr = 0x000203ad},
	{.symbol = _addBootArg_string, .addr = 0x00023853},
	{.symbol = _addConfigurationTable_string, .addr = 0x0002a204},
	{.symbol = _add_symbol_string, .addr = 0x000269d7},
	{.symbol = _adler32_string, .addr = 0x000347c7},
	{.symbol = _arc4_init_string, .addr = 0x00027973},
	{.symbol = _arc4random_string, .addr = 0x00027bac},
	{.symbol = _arc4random_addrandom_string, .addr = 0x00027a7b},
	{.symbol = _arc4random_buf_string, .addr = 0x00027b09},
	{.symbol = _arc4random_stir_string, .addr = 0x00027a72},
	{.symbol = _arc4random_uniform_string, .addr = 0x00027d1c},
	{.symbol = _atoi_string, .addr = 0x00034718},
	{.symbol = _bcopy_string, .addr = 0x0003501e},
	{.symbol = _bcopy16_string, .addr = 0x00034ffe},
	{.symbol = _bcopy_no_overwrite_string, .addr = 0x00034fef},
	{.symbol = _bgetc_string, .addr = 0x0002c7bd},
	{.symbol = _bind_location_string, .addr = 0x00026591},
	{.symbol = _bind_macho_string, .addr = 0x000270fc},
	{.symbol = _bios_string, .addr = 0x000203dd},
	{.symbol = _biosDevIsCDROM_string, .addr = 0x00027e74},
	{.symbol = _biosread_string, .addr = 0x0002c26e},
	{.symbol = _boot_string, .addr = 0x00021659},
	{.symbol = _bootArgs_string, .addr = 0x0003a36c},
	{.symbol = _bootArgsLegacy_string, .addr = 0x0003a368},
	{.symbol = _bootInfo_string, .addr = 0x0003a370},
	{.symbol = _bsearch_string, .addr = 0x00034865},
	{.symbol = _build_pci_dt_string, .addr = 0x0002e328},
	{.symbol = _bzero_string, .addr = 0x00034a8d},
	{.symbol = _chainLoad_string, .addr = 0x000249b5},
	{.symbol = _chainbootdev_string, .addr = 0x000204b0},
	{.symbol = _chainbootflag_string, .addr = 0x000204b1},
	{.symbol = _clearBootArgs_string, .addr = 0x000238ab},
	{.symbol = _clearScreenRows_string, .addr = 0x0002bf32},
	{.symbol = _close_string, .addr = 0x00024a5d},
	{.symbol = _common_boot_string, .addr = 0x000209c5},
	{.symbol = _continue_at_low_address_string, .addr = 0x000202b4},
	{.symbol = _convertHexStr2Binary_string, .addr = 0x00033577},
	{.symbol = _copyArgument_string, .addr = 0x00023070},
	{.symbol = _copyMultibootInfo_string, .addr = 0x0002473b},
	{.symbol = _crc32_string, .addr = 0x00035ec3},
	{.symbol = _debug_putc_string, .addr = 0x0002b941},
	{.symbol = _decompress_lzss_string, .addr = 0x0002df55},
	{.symbol = _delay_string, .addr = 0x0002be7a},
	{.symbol = _determine_safe_hi_addr_string, .addr = 0x00024615},
	{.symbol = _devprop_add_device_string, .addr = 0x00033c33},
	{.symbol = _devprop_add_value_string, .addr = 0x000339f7},
	{.symbol = _devprop_create_string_string, .addr = 0x000339c2},
	{.symbol = _devprop_free_string_string, .addr = 0x000337a1},
	{.symbol = _devprop_generate_string_string, .addr = 0x00033809},
	{.symbol = _devprop_make_device_string, .addr = 0x00033b31},
	{.symbol = _diskFreeMap_string, .addr = 0x00027ef3},
	{.symbol = _diskIsCDROM_string, .addr = 0x00027e98},
	{.symbol = _diskRead_string, .addr = 0x000289bb},
	{.symbol = _diskResetBootVolumes_string, .addr = 0x00028477},
	{.symbol = _diskScanBootVolumes_string, .addr = 0x00028cd5},
	{.symbol = _diskSeek_string, .addr = 0x00027d76},
	{.symbol = _dump_pci_dt_string, .addr = 0x0002e131},
	{.symbol = _ebiosEjectMedia_string, .addr = 0x0002bffd},
	{.symbol = _ebiosread_string, .addr = 0x0002c19b},
	{.symbol = _ebioswrite_string, .addr = 0x0002c0aa},
	{.symbol = _efi_guid_compare_string, .addr = 0x00035f1c},
	{.symbol = _efi_guid_is_null_string, .addr = 0x00035ef4},
	{.symbol = _efi_guid_unparse_upper_string, .addr = 0x00035f6d},
	{.symbol = _efi_inject_get_devprop_string_string, .addr = 0x00033cb9},
	{.symbol = _enableA20_string, .addr = 0x00029f38},
	{.symbol = _enable_pci_devs_string, .addr = 0x0002e102},
	{.symbol = _error_string, .addr = 0x0002bb46},
	{.symbol = _execute_hook_string, .addr = 0x000278ff},
	{.symbol = _file_size_string, .addr = 0x00025469},
	{.symbol = _finalizeBootStruct_string, .addr = 0x000299a7},
	{.symbol = _finalizeEFIConfigTable_string, .addr = 0x0002a00d},
	{.symbol = _free_string, .addr = 0x00034c1b},
	{.symbol = _freeFilteredBVChain_string, .addr = 0x00027ebf},
	{.symbol = _free_platform_env_string, .addr = 0x00025581},
	{.symbol = _gAppleBootPictRLE_string, .addr = 0x00038ea0},
	{.symbol = _gCompareTable_string, .addr = 0x0003c370},
	{.symbol = _gCompareTableCompressed_string, .addr = 0x0003a718},
	{.symbol = _gEfiAcpi20TableGuid_string, .addr = 0x0003a394},
	{.symbol = _gEfiAcpiTableGuid_string, .addr = 0x0003a384},
	{.symbol = _gEfiConfigurationTable32_string, .addr = 0x0003c1b0},
	{.symbol = _gEfiConfigurationTable64_string, .addr = 0x0003c280},
	{.symbol = _gEfiConfigurationTableNode_string, .addr = 0x0003a380},
	{.symbol = _gEfiSmbiosTableGuid_string, .addr = 0x000398e8},
	{.symbol = _gLowerCaseTable_string, .addr = 0x0003c374},
	{.symbol = _gLowerCaseTableCompressed_string, .addr = 0x0003a440},
	{.symbol = _gNumTables32_string, .addr = 0x0003a3a4},
	{.symbol = _gNumTables64_string, .addr = 0x0003a3a8},
	{.symbol = _gST32_string, .addr = 0x0003a378},
	{.symbol = _gST64_string, .addr = 0x0003a37c},
	{.symbol = _getBVChainForBIOSDev_string, .addr = 0x00027d57},
	{.symbol = _getBoolForKey_string, .addr = 0x0002b71b},
	{.symbol = _getBootArgs_string, .addr = 0x0002999d},
	{.symbol = _getBootOptions_string, .addr = 0x0002396d},
	{.symbol = _getBootVolumeDescription_string, .addr = 0x00028118},
	{.symbol = _getBootVolumeRef_string, .addr = 0x00024d1c},
	{.symbol = _getBvChain_string, .addr = 0x00020540},
	{.symbol = _getConventionalMemorySize_string, .addr = 0x0002c347},
	{.symbol = _getCursorPositionAndType_string, .addr = 0x0002bf55},
	{.symbol = _getDeviceDescription_string, .addr = 0x00024aa7},
	{.symbol = _getExtendedMemorySize_string, .addr = 0x0002c367},
	{.symbol = _getIntForKey_string, .addr = 0x0002b631},
	{.symbol = _getKernelCachePath_string, .addr = 0x000205fb},
	{.symbol = _getMemoryInfoString_string, .addr = 0x00022f7a},
	{.symbol = _getMemoryMap_string, .addr = 0x0002c62a},
	{.symbol = _getNextArg_string, .addr = 0x0002af64},
	{.symbol = _getPciRootUID_string, .addr = 0x00034530},
	{.symbol = _getPlatformName_string, .addr = 0x00029f24},
	{.symbol = _getSmbiosOriginal_string, .addr = 0x0002bc52},
	{.symbol = _getStringForKey_string, .addr = 0x0002b7c1},
	{.symbol = _getStringFromUUID_string, .addr = 0x0003372a},
	{.symbol = _getUUIDFromString_string, .addr = 0x00033657},
	{.symbol = _getVBEInfo_string, .addr = 0x0002c982},
	{.symbol = _getVBEModeInfo_string, .addr = 0x0002c938},
	{.symbol = _getValueForBootKey_string, .addr = 0x0002b398},
	{.symbol = _getValueForConfigTableKey_string, .addr = 0x0002b43f},
	{.symbol = _getValueForKey_string, .addr = 0x0002b4f4},
	{.symbol = _getVideoMode_string, .addr = 0x00029932},
	{.symbol = _getVolumeLabelAlias_string, .addr = 0x0002802f},
	{.symbol = _get_callback_string, .addr = 0x000266c5},
	{.symbol = _get_drive_info_string, .addr = 0x0002c4ed},
	{.symbol = _get_env_string, .addr = 0x00025b75},
	{.symbol = _get_env_ptr_string, .addr = 0x00025b03},
	{.symbol = _get_env_var_string, .addr = 0x00025b38},
	{.symbol = _get_num_tables_string, .addr = 0x000331cb},
	{.symbol = _get_num_tables64_string, .addr = 0x000331dc},
	{.symbol = _getc_string, .addr = 0x0002ba09},
	{.symbol = _getchar_string, .addr = 0x0002bc15},
	{.symbol = _gettimeofday_string, .addr = 0x0002f8da},
	{.symbol = _halt_string, .addr = 0x00020383},
	{.symbol = _handle_symtable_string, .addr = 0x00026fa1},
	{.symbol = _hi_multiboot_string, .addr = 0x00024871},
	{.symbol = _initBooterLog_string, .addr = 0x0002bac0},
	{.symbol = _initKernBootStruct_string, .addr = 0x00029da4},
	{.symbol = _init_ut_fnc_string, .addr = 0x0002bc4d},
	{.symbol = _initialize_runtime_string, .addr = 0x00021617},
	{.symbol = _iob_from_fdesc_string, .addr = 0x00024a3a},
	{.symbol = _is_no_emulation_string, .addr = 0x0002c46e},
	{.symbol = _jump_to_chainbooter_string, .addr = 0x000202ca},
	{.symbol = _loadBooterConfig_string, .addr = 0x0002b207},
	{.symbol = _loadConfigFile_string, .addr = 0x0002b2c8},
	{.symbol = _loadOverrideConfig_string, .addr = 0x0002b157},
	{.symbol = _loadSystemConfig_string, .addr = 0x0002b0a2},
	{.symbol = _localVPrintf_string, .addr = 0x0002b9a9},
	{.symbol = _longjmp_string, .addr = 0x00035e6a},
	{.symbol = _lookup_all_symbols_string, .addr = 0x00026640},
	{.symbol = _lookup_symbol_string, .addr = 0x0003a250},
	{.symbol = _lspci_string, .addr = 0x00023728},
	{.symbol = _malloc_string, .addr = 0x00034f78},
	{.symbol = _malloc_init_string, .addr = 0x00034aaf},
	{.symbol = _matchVolumeToString_string, .addr = 0x00027f25},
	{.symbol = _memcmp_string, .addr = 0x00034832},
	{.symbol = _memcpy_string, .addr = 0x00034fcd},
	{.symbol = _memmove_string, .addr = 0x000348ef},
	{.symbol = _memset_string, .addr = 0x00034a60},
	{.symbol = _moduleCallbacks_string, .addr = 0x0003a248},
	{.symbol = _moduleSymbols_string, .addr = 0x0003a24c},
	{.symbol = _msglog_string, .addr = 0x0002bbe5},
	{.symbol = _multiboot_to_boot_string, .addr = 0x000249fa},
	{.symbol = _newEmptyStringWithLength_string, .addr = 0x0002b928},
	{.symbol = _newFilteredBVChain_string, .addr = 0x00028231},
	{.symbol = _newGPTBVRef_string, .addr = 0x00028abf},
	{.symbol = _newString_string, .addr = 0x0002b8fd},
	{.symbol = _newStringForKey_string, .addr = 0x0002b852},
	{.symbol = _newStringWithFormat_string, .addr = 0x0002b9be},
	{.symbol = _newStringWithLength_string, .addr = 0x0002afff},
	{.symbol = _open_string, .addr = 0x00024fd4},
	{.symbol = _open_bvdev_string, .addr = 0x00024ffd},
	{.symbol = _parse_mach_string, .addr = 0x00027449},
	{.symbol = _pause_string, .addr = 0x0002bc01},
	{.symbol = _pci_config_read16_string, .addr = 0x0002e090},
	{.symbol = _pci_config_read32_string, .addr = 0x0002e0bb},
	{.symbol = _pci_config_read8_string, .addr = 0x0002e066},
	{.symbol = _pci_config_write16_string, .addr = 0x0002e0d3},
	{.symbol = _pci_config_write32_string, .addr = 0x0002e30d},
	{.symbol = _pci_config_write8_string, .addr = 0x0002e2df},
	{.symbol = _platform_env_string, .addr = 0x0003a234},
	{.symbol = _prf_string, .addr = 0x00035b0a},
	{.symbol = _printMemoryInfo_string, .addr = 0x00023782},
	{.symbol = _printf_string, .addr = 0x0002baa5},
	{.symbol = _processBootOptions_string, .addr = 0x000230f7},
	{.symbol = _promptForRescanOption_string, .addr = 0x00022c94},
	{.symbol = _putc_string, .addr = 0x0002c073},
	{.symbol = _putca_string, .addr = 0x0002c033},
	{.symbol = _putchar_string, .addr = 0x0002ba20},
	{.symbol = _re_set_env_string, .addr = 0x00025ac6},
	{.symbol = _re_set_env_copy_string, .addr = 0x000262cc},
	{.symbol = _read_string, .addr = 0x000253ab},
	{.symbol = _readBootSector_string, .addr = 0x00028a62},
	{.symbol = _readDefaultPlatformName_string, .addr = 0x0002be00},
	{.symbol = _readKeyboardShiftFlags_string, .addr = 0x0002c414},
	{.symbol = _readKeyboardStatus_string, .addr = 0x0002c43b},
	{.symbol = _readSMBIOS_string, .addr = 0x0002bcdf},
	{.symbol = _realloc_string, .addr = 0x00034f8c},
	{.symbol = _reallyVPrint_string, .addr = 0x0002b968},
	{.symbol = _rebase_location_string, .addr = 0x0002657b},
	{.symbol = _rebase_macho_string, .addr = 0x0002630c},
	{.symbol = _register_hook_callback_string, .addr = 0x00027867},
	{.symbol = _replace_function_string, .addr = 0x0002696a},
	{.symbol = _replace_function_any_string, .addr = 0x000269b0},
	{.symbol = _replace_system_function_string, .addr = 0x000269c2},
	{.symbol = _rescanBIOSDevice_string, .addr = 0x000284de},
	{.symbol = _reserveKernBootStruct_string, .addr = 0x00029d77},
	{.symbol = _reserveKernLegacyBootStruct_string, .addr = 0x00029bb4},
	{.symbol = _resolveConfig_string, .addr = 0x0002af02},
	{.symbol = _root_pci_dev_string, .addr = 0x0003c150},
	{.symbol = _rtc_read_clock_string, .addr = 0x00033d7a},
	{.symbol = _safe_set_env_string, .addr = 0x0002628e},
	{.symbol = _safe_set_env_copy_string, .addr = 0x000262b5},
	{.symbol = _scanBootVolumes_string, .addr = 0x00024c6a},
	{.symbol = _scanDisks_string, .addr = 0x00024e8d},
	{.symbol = _scan_cpu_string, .addr = 0x0002ebce},
	{.symbol = _scan_pci_bus_string, .addr = 0x0002e1b6},
	{.symbol = _scan_platform_string, .addr = 0x00025533},
	{.symbol = _scollPage_string, .addr = 0x0002bed9},
	{.symbol = _selectBootVolume_string, .addr = 0x00024b36},
	{.symbol = _setActiveDisplayPage_string, .addr = 0x0002beb0},
	{.symbol = _setBootArgsVideoMode_string, .addr = 0x0002991f},
	{.symbol = _setBootArgsVideoStruct_string, .addr = 0x00029942},
	{.symbol = _setBootGlobals_string, .addr = 0x0002548f},
	{.symbol = _setCursorPosition_string, .addr = 0x0002bfc4},
	{.symbol = _setCursorType_string, .addr = 0x0002bf9a},
	{.symbol = _setRootVolume_string, .addr = 0x00024a87},
	{.symbol = _setVBEMode_string, .addr = 0x0002c8ea},
	{.symbol = _setVBEPalette_string, .addr = 0x0002c890},
	{.symbol = _set_env_string, .addr = 0x00026182},
	{.symbol = _set_env_copy_string, .addr = 0x0002616b},
	{.symbol = _setjmp_string, .addr = 0x00035e50},
	{.symbol = _setupBooterLog_string, .addr = 0x0002ba5f},
	{.symbol = _setupDeviceProperties_string, .addr = 0x00033cf3},
	{.symbol = _setupFakeEfi_string, .addr = 0x0002a3e3},
	{.symbol = _setupSmbiosConfigFile_string, .addr = 0x0002a12e},
	{.symbol = _setup_acpi_string, .addr = 0x0002a33e},
	{.symbol = _setup_pci_devs_string, .addr = 0x0002e181},
	{.symbol = _showError_string, .addr = 0x00025541},
	{.symbol = _showHelp_string, .addr = 0x00022eb5},
	{.symbol = _showMessage_string, .addr = 0x00022e99},
	{.symbol = _showTextBuffer_string, .addr = 0x00022cb2},
	{.symbol = _showTextFile_string, .addr = 0x00022e01},
	{.symbol = _sleep_string, .addr = 0x0002c813},
	{.symbol = _snprintf_string, .addr = 0x00035b5a},
	{.symbol = _sprintf_string, .addr = 0x00035b24},
	{.symbol = _startprog_string, .addr = 0x0002038d},
	{.symbol = _stop_string, .addr = 0x0002bb11},
	{.symbol = _strbreak_string, .addr = 0x00034909},
	{.symbol = _strcat_string, .addr = 0x00034788},
	{.symbol = _strchr_string, .addr = 0x000347a8},
	{.symbol = _strcmp_string, .addr = 0x000345ff},
	{.symbol = _strcpy_string, .addr = 0x0003465d},
	{.symbol = _strdup_string, .addr = 0x000348a9},
	{.symbol = _strlcat_string, .addr = 0x0003499c},
	{.symbol = _strlcpy_string, .addr = 0x000346d3},
	{.symbol = _strlen_string, .addr = 0x0003476e},
	{.symbol = _strncat_string, .addr = 0x0003473c},
	{.symbol = _strncmp_string, .addr = 0x00034628},
	{.symbol = _strncpy_string, .addr = 0x00034675},
	{.symbol = _strstr_string, .addr = 0x000349f9},
	{.symbol = _strtol_string, .addr = 0x00035b9f},
	{.symbol = _strtoul_string, .addr = 0x00035d00},
	{.symbol = _testBiosread_string, .addr = 0x0002990d},
	{.symbol = _testFAT32EFIBootSector_string, .addr = 0x000289ea},
	{.symbol = _textAddress_string, .addr = 0x0003a238},
	{.symbol = _textSection_string, .addr = 0x0003a240},
	{.symbol = _time18_string, .addr = 0x0002c3da},
	{.symbol = _unset_env_string, .addr = 0x00025aaf},
	{.symbol = _uterror_string, .addr = 0x0003c160},
	{.symbol = _utf_decodestr_string, .addr = 0x000341d8},
	{.symbol = _utf_encodestr_string, .addr = 0x000342b3},
	{.symbol = _verbose_string, .addr = 0x0002bbae},
	{.symbol = _video_mode_string, .addr = 0x0002c31e},
	{.symbol = _vsnprintf_string, .addr = 0x00035acd},
	{.symbol = _waitThenReload_string, .addr = 0x000246dd},
	{.symbol = _write_string, .addr = 0x0002540a},
	{.symbol = _zalloced_size_string, .addr = 0x0003c378},
	{.symbol = _zout_string, .addr = 0x0003c37c},
	{.symbol = boot2_string, .addr = 0x00020200},
};
