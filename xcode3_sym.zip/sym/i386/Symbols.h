typedef struct {
	char*	symbol;
	unsigned int	addr;
} symbol_t;

static char _AllocateKernelMemory_string[] = "_AllocateKernelMemory";
static char _AllocateMemoryRange_string[] = "_AllocateMemoryRange";
static char _BeFSGetDescription_string[] = "_BeFSGetDescription";
static char _BeFSProbe_string[] = "_BeFSProbe";
static char _BinaryUnicodeCompare_string[] = "_BinaryUnicodeCompare";
static char _CacheInit_string[] = "_CacheInit";
static char _CacheRead_string[] = "_CacheRead";
static char _CacheReset_string[] = "_CacheReset";
static char _CreateUUIDString_string[] = "_CreateUUIDString";
static char _DT__AddChild_string[] = "_DT__AddChild";
static char _DT__AddProperty_string[] = "_DT__AddProperty";
static char _DT__Finalize_string[] = "_DT__Finalize";
static char _DT__FindNode_string[] = "_DT__FindNode";
static char _DT__FlattenDeviceTree_string[] = "_DT__FlattenDeviceTree";
static char _DT__FreeNode_string[] = "_DT__FreeNode";
static char _DT__FreeProperty_string[] = "_DT__FreeProperty";
static char _DT__GetName_string[] = "_DT__GetName";
static char _DT__Initialize_string[] = "_DT__Initialize";
static char _DecodeKernel_string[] = "_DecodeKernel";
static char _DecodeMachO_string[] = "_DecodeMachO";
static char _EX2GetDescription_string[] = "_EX2GetDescription";
static char _EX2Probe_string[] = "_EX2Probe";
static char _EXFATGetDescription_string[] = "_EXFATGetDescription";
static char _EXFATGetUUID_string[] = "_EXFATGetUUID";
static char _EXFATProbe_string[] = "_EXFATProbe";
static char _FastRelString_string[] = "_FastRelString";
static char _FastUnicodeCompare_string[] = "_FastUnicodeCompare";
static char _FileLoadDrivers_string[] = "_FileLoadDrivers";
static char _FindAcpiTables_string[] = "_FindAcpiTables";
static char _FreeBSDGetDescription_string[] = "_FreeBSDGetDescription";
static char _FreeBSDProbe_string[] = "_FreeBSDProbe";
static char _GPT_BASICDATA2_GUID_string[] = "_GPT_BASICDATA2_GUID";
static char _GPT_BASICDATA_GUID_string[] = "_GPT_BASICDATA_GUID";
static char _GPT_BOOT_GUID_string[] = "_GPT_BOOT_GUID";
static char _GPT_EFISYS_GUID_string[] = "_GPT_EFISYS_GUID";
static char _GPT_HFS_GUID_string[] = "_GPT_HFS_GUID";
static char _Gdt_string[] = "_Gdt";
static char _Gdtr_string[] = "_Gdtr";
static char _GetChecksum_string[] = "_GetChecksum";
static char _GetDirEntry_string[] = "_GetDirEntry";
static char _GetFileInfo_string[] = "_GetFileInfo";
static char _GetgPlatformName_string[] = "_GetgPlatformName";
static char _GetgRootDevice_string[] = "_GetgRootDevice";
static char _Getgboardproduct_string[] = "_Getgboardproduct";
static char _HFSFree_string[] = "_HFSFree";
static char _HFSGetDescription_string[] = "_HFSGetDescription";
static char _HFSGetDirEntry_string[] = "_HFSGetDirEntry";
static char _HFSGetFileBlock_string[] = "_HFSGetFileBlock";
static char _HFSGetUUID_string[] = "_HFSGetUUID";
static char _HFSInitPartition_string[] = "_HFSInitPartition";
static char _HFSLoadFile_string[] = "_HFSLoadFile";
static char _HFSLoadVerbose_string[] = "_HFSLoadVerbose";
static char _HFSProbe_string[] = "_HFSProbe";
static char _HFSReadFile_string[] = "_HFSReadFile";
static char _Idtr_prot_string[] = "_Idtr_prot";
static char _Idtr_real_string[] = "_Idtr_real";
static char _InitBootPrompt_string[] = "_InitBootPrompt";
static char _InitDriverSupport_string[] = "_InitDriverSupport";
static char _LoadDriverMKext_string[] = "_LoadDriverMKext";
static char _LoadDriverPList_string[] = "_LoadDriverPList";
static char _LoadDrivers_string[] = "_LoadDrivers";
static char _LoadFile_string[] = "_LoadFile";
static char _LoadMatchedModules_string[] = "_LoadMatchedModules";
static char _LoadThinFatFile_string[] = "_LoadThinFatFile";
static char _LoadVolumeFile_string[] = "_LoadVolumeFile";
static char _MD5Final_string[] = "_MD5Final";
static char _MD5Init_string[] = "_MD5Init";
static char _MD5Update_string[] = "_MD5Update";
static char _MSDOSFree_string[] = "_MSDOSFree";
static char _MSDOSGetDescription_string[] = "_MSDOSGetDescription";
static char _MSDOSGetDirEntry_string[] = "_MSDOSGetDirEntry";
static char _MSDOSGetFileBlock_string[] = "_MSDOSGetFileBlock";
static char _MSDOSGetUUID_string[] = "_MSDOSGetUUID";
static char _MSDOSInitPartition_string[] = "_MSDOSInitPartition";
static char _MSDOSLoadFile_string[] = "_MSDOSLoadFile";
static char _MSDOSProbe_string[] = "_MSDOSProbe";
static char _MSDOSReadFile_string[] = "_MSDOSReadFile";
static char _MatchLibraries_string[] = "_MatchLibraries";
static char _NTFSGetDescription_string[] = "_NTFSGetDescription";
static char _NTFSGetUUID_string[] = "_NTFSGetUUID";
static char _NTFSProbe_string[] = "_NTFSProbe";
static char _OpenBSDGetDescription_string[] = "_OpenBSDGetDescription";
static char _OpenBSDProbe_string[] = "_OpenBSDProbe";
static char _ParseXMLFile_string[] = "_ParseXMLFile";
static char _ReadFileAtOffset_string[] = "_ReadFileAtOffset";
static char _Register_Acpi_Efi_string[] = "_Register_Acpi_Efi";
static char _Register_Smbios_Efi_string[] = "_Register_Smbios_Efi";
static char _SetgPlatformName_string[] = "_SetgPlatformName";
static char _SetgRootDevice_string[] = "_SetgRootDevice";
static char _Setgboardproduct_string[] = "_Setgboardproduct";
static char _ThinFatFile_string[] = "_ThinFatFile";
static char _XMLCastArray_string[] = "_XMLCastArray";
static char _XMLCastBoolean_string[] = "_XMLCastBoolean";
static char _XMLCastDict_string[] = "_XMLCastDict";
static char _XMLCastInteger_string[] = "_XMLCastInteger";
static char _XMLCastString_string[] = "_XMLCastString";
static char _XMLCastStringOffset_string[] = "_XMLCastStringOffset";
static char _XMLDecode_string[] = "_XMLDecode";
static char _XMLFreeTag_string[] = "_XMLFreeTag";
static char _XMLGetElement_string[] = "_XMLGetElement";
static char _XMLGetProperty_string[] = "_XMLGetProperty";
static char _XMLIsType_string[] = "_XMLIsType";
static char _XMLParseFile_string[] = "_XMLParseFile";
static char _XMLParseNextTag_string[] = "_XMLParseNextTag";
static char _XMLTagCount_string[] = "_XMLTagCount";
static char __DATA__bss__begin_string[] = "__DATA__bss__begin";
static char __DATA__bss__end_string[] = "__DATA__bss__end";
static char __DATA__common__begin_string[] = "__DATA__common__begin";
static char __DATA__common__end_string[] = "__DATA__common__end";
static char ___bzero_string[] = "___bzero";
static char ___convertImage_string[] = "___convertImage";
static char ___decodeRLE_string[] = "___decodeRLE";
static char ___divdi3_string[] = "___divdi3";
static char ___drawColorRectangle_string[] = "___drawColorRectangle";
static char ___drawDataRectangle_string[] = "___drawDataRectangle";
static char ___getNumberArrayFromProperty_string[] = "___getNumberArrayFromProperty";
static char ___getVESAModeWithProperties_string[] = "___getVESAModeWithProperties";
static char ___moddi3_string[] = "___moddi3";
static char ___qdivrem_string[] = "___qdivrem";
static char ___setVESAGraphicsMode_string[] = "___setVESAGraphicsMode";
static char ___setVideoMode_string[] = "___setVideoMode";
static char ___udivdi3_string[] = "___udivdi3";
static char ___umoddi3_string[] = "___umoddi3";
static char __bp_string[] = "__bp";
static char __hi_malloc_string[] = "__hi_malloc";
static char __hi_strdup_string[] = "__hi_strdup";
static char __prot_to_real_string[] = "__prot_to_real";
static char __real_to_prot_string[] = "__real_to_prot";
static char __sp_string[] = "__sp";
static char __switch_stack_string[] = "__switch_stack";
static char _addBootArg_string[] = "_addBootArg";
static char _addConfigurationTable_string[] = "_addConfigurationTable";
static char _add_symbol_string[] = "_add_symbol";
static char _adler32_string[] = "_adler32";
static char _arc4_init_string[] = "_arc4_init";
static char _arc4rand_string[] = "_arc4rand";
static char _arc4random_string[] = "_arc4random";
static char _archCpuType_string[] = "_archCpuType";
static char _ascii_hex_to_int_string[] = "_ascii_hex_to_int";
static char _atoi_string[] = "_atoi";
static char _b_lseek_string[] = "_b_lseek";
static char _bcopy_string[] = "_bcopy";
static char _bcopy16_string[] = "_bcopy16";
static char _bcopy_no_overwrite_string[] = "_bcopy_no_overwrite";
static char _bgetc_string[] = "_bgetc";
static char _bind_location_string[] = "_bind_location";
static char _bind_macho_string[] = "_bind_macho";
static char _bios_string[] = "_bios";
static char _biosDevIsCDROM_string[] = "_biosDevIsCDROM";
static char _biosread_string[] = "_biosread";
static char _boot_string[] = "_boot";
static char _bootArgs_string[] = "_bootArgs";
static char _bootArgs107_string[] = "_bootArgs107";
static char _bootArgs108_string[] = "_bootArgs108";
static char _bootArgsLegacy_string[] = "_bootArgsLegacy";
static char _bootInfo_string[] = "_bootInfo";
static char _bsearch_string[] = "_bsearch";
static char _build_pci_dt_string[] = "_build_pci_dt";
static char _bzero_string[] = "_bzero";
static char _chainLoad_string[] = "_chainLoad";
static char _chainbootdev_string[] = "_chainbootdev";
static char _chainbootflag_string[] = "_chainbootflag";
static char _checksum8_string[] = "_checksum8";
static char _clearBootArgs_string[] = "_clearBootArgs";
static char _clearScreenRows_string[] = "_clearScreenRows";
static char _close_string[] = "_close";
static char _closedir_string[] = "_closedir";
static char _common_boot_string[] = "_common_boot";
static char _continue_at_low_address_string[] = "_continue_at_low_address";
static char _convertHexStr2Binary_string[] = "_convertHexStr2Binary";
static char _copyArgument_string[] = "_copyArgument";
static char _copyMultibootInfo_string[] = "_copyMultibootInfo";
static char _crc32_string[] = "_crc32";
static char _cursor_string[] = "_cursor";
static char _decompress_lzss_string[] = "_decompress_lzss";
static char _delay_string[] = "_delay";
static char _determine_safe_hi_addr_string[] = "_determine_safe_hi_addr";
static char _devices_number_string[] = "_devices_number";
static char _devprop_add_device_string[] = "_devprop_add_device";
static char _devprop_add_value_string[] = "_devprop_add_value";
static char _devprop_create_string_string[] = "_devprop_create_string";
static char _devprop_free_string_string[] = "_devprop_free_string";
static char _devprop_generate_string_string[] = "_devprop_generate_string";
static char _diskFreeMap_string[] = "_diskFreeMap";
static char _diskIsCDROM_string[] = "_diskIsCDROM";
static char _diskRead_string[] = "_diskRead";
static char _diskResetBootVolumes_string[] = "_diskResetBootVolumes";
static char _diskScanBootVolumes_string[] = "_diskScanBootVolumes";
static char _diskSeek_string[] = "_diskSeek";
static char _dump_pci_dt_string[] = "_dump_pci_dt";
static char _ebiosEjectMedia_string[] = "_ebiosEjectMedia";
static char _ebiosread_string[] = "_ebiosread";
static char _ebioswrite_string[] = "_ebioswrite";
static char _efi_guid_compare_string[] = "_efi_guid_compare";
static char _efi_guid_is_null_string[] = "_efi_guid_is_null";
static char _efi_guid_unparse_upper_string[] = "_efi_guid_unparse_upper";
static char _efi_inject_get_devprop_string_string[] = "_efi_inject_get_devprop_string";
static char _enableA20_string[] = "_enableA20";
static char _enable_pci_devs_string[] = "_enable_pci_devs";
static char _error_string[] = "_error";
static char _execute_hook_string[] = "_execute_hook";
static char _file_size_string[] = "_file_size";
static char _finalizeBootStruct_string[] = "_finalizeBootStruct";
static char _finalizeEFIConfigTable_string[] = "_finalizeEFIConfigTable";
static char _free_string[] = "_free";
static char _freeFilteredBVChain_string[] = "_freeFilteredBVChain";
static char _free_platform_env_string[] = "_free_platform_env";
static char _gAppleBootPictRLE_string[] = "_gAppleBootPictRLE";
static char _gBIOSBootVolume_string[] = "_gBIOSBootVolume";
static char _gBinaryAddress_string[] = "_gBinaryAddress";
static char _gBootFileType_string[] = "_gBootFileType";
static char _gBootVolume_string[] = "_gBootVolume";
static char _gCompareTable_string[] = "_gCompareTable";
static char _gCompareTableCompressed_string[] = "_gCompareTableCompressed";
static char _gEfiAcpi20TableGuid_string[] = "_gEfiAcpi20TableGuid";
static char _gEfiAcpiTableGuid_string[] = "_gEfiAcpiTableGuid";
static char _gEfiConfigurationTable32_string[] = "_gEfiConfigurationTable32";
static char _gEfiConfigurationTable64_string[] = "_gEfiConfigurationTable64";
static char _gEfiConfigurationTableNode_string[] = "_gEfiConfigurationTableNode";
static char _gEfiMpsTableGuid_string[] = "_gEfiMpsTableGuid";
static char _gEfiSmbiosTableGuid_string[] = "_gEfiSmbiosTableGuid";
static char _gErrors_string[] = "_gErrors";
static char _gFSLoadAddress_string[] = "_gFSLoadAddress";
static char _gHaveKernelCache_string[] = "_gHaveKernelCache";
static char _gLowerCaseTable_string[] = "_gLowerCaseTable";
static char _gLowerCaseTableCompressed_string[] = "_gLowerCaseTableCompressed";
static char _gMemoryMapNode_string[] = "_gMemoryMapNode";
static char _gNumTables32_string[] = "_gNumTables32";
static char _gNumTables64_string[] = "_gNumTables64";
static char _gST32_string[] = "_gST32";
static char _gST64_string[] = "_gST64";
static char _gVerboseMode_string[] = "_gVerboseMode";
static char _getBVChainForBIOSDev_string[] = "_getBVChainForBIOSDev";
static char _getBoolForKey_string[] = "_getBoolForKey";
static char _getBootArgs_string[] = "_getBootArgs";
static char _getBootOptions_string[] = "_getBootOptions";
static char _getBootVolumeDescription_string[] = "_getBootVolumeDescription";
static char _getBootVolumeRef_string[] = "_getBootVolumeRef";
static char _getBvChain_string[] = "_getBvChain";
static char _getColorForKey_string[] = "_getColorForKey";
static char _getConsoleCursor_string[] = "_getConsoleCursor";
static char _getConsoleMsg_string[] = "_getConsoleMsg";
static char _getConventionalMemorySize_string[] = "_getConventionalMemorySize";
static char _getCursorPositionAndType_string[] = "_getCursorPositionAndType";
static char _getDeviceDescription_string[] = "_getDeviceDescription";
static char _getDimensionForKey_string[] = "_getDimensionForKey";
static char _getEDID_string[] = "_getEDID";
static char _getExtendedMemorySize_string[] = "_getExtendedMemorySize";
static char _getIntForKey_string[] = "_getIntForKey";
static char _getKernelCachePath_string[] = "_getKernelCachePath";
static char _getMemoryInfoString_string[] = "_getMemoryInfoString";
static char _getMemoryMap_string[] = "_getMemoryMap";
static char _getNextArg_string[] = "_getNextArg";
static char _getPciRootUID_string[] = "_getPciRootUID";
static char _getPlatformName_string[] = "_getPlatformName";
static char _getSmbiosOriginal_string[] = "_getSmbiosOriginal";
static char _getStringForKey_string[] = "_getStringForKey";
static char _getStringFromUUID_string[] = "_getStringFromUUID";
static char _getUUIDFromString_string[] = "_getUUIDFromString";
static char _getVBEInfo_string[] = "_getVBEInfo";
static char _getVBEModeInfo_string[] = "_getVBEModeInfo";
static char _getValueForBootKey_string[] = "_getValueForBootKey";
static char _getValueForConfigTableKey_string[] = "_getValueForConfigTableKey";
static char _getValueForKey_string[] = "_getValueForKey";
static char _getVideoMode_string[] = "_getVideoMode";
static char _getVolumeLabelAlias_string[] = "_getVolumeLabelAlias";
static char _get_callback_string[] = "_get_callback";
static char _get_drive_info_string[] = "_get_drive_info";
static char _get_env_string[] = "_get_env";
static char _get_env_ptr_string[] = "_get_env_ptr";
static char _get_env_var_string[] = "_get_env_var";
static char _get_num_tables_string[] = "_get_num_tables";
static char _get_num_tables64_string[] = "_get_num_tables64";
static char _get_pci_dev_path_string[] = "_get_pci_dev_path";
static char _getc_string[] = "_getc";
static char _getchar_string[] = "_getchar";
static char _gfps_ptr_string[] = "_gfps_ptr";
static char _h_buf_error_string[] = "_h_buf_error";
static char _halt_string[] = "_halt";
static char _handle_symtable_string[] = "_handle_symtable";
static char _hi_multiboot_string[] = "_hi_multiboot";
static char _imps_apic_cpu_map_string[] = "_imps_apic_cpu_map";
static char _imps_cpu_apic_map_string[] = "_imps_cpu_apic_map";
static char _imps_enabled_string[] = "_imps_enabled";
static char _imps_lapic_addr_string[] = "_imps_lapic_addr";
static char _imps_num_cpus_string[] = "_imps_num_cpus";
static char _imps_probe_string[] = "_imps_probe";
static char _imps_release_cpus_string[] = "_imps_release_cpus";
static char _initBooterLog_string[] = "_initBooterLog";
static char _initKernBootStruct_string[] = "_initKernBootStruct";
static char _init_module_system_string[] = "_init_module_system";
static char _init_ut_fnc_string[] = "_init_ut_fnc";
static char _initialize_runtime_string[] = "_initialize_runtime";
static char _is_module_loaded_string[] = "_is_module_loaded";
static char _is_no_emulation_string[] = "_is_no_emulation";
static char _itoa_string[] = "_itoa";
static char _jump_to_chainbooter_string[] = "_jump_to_chainbooter";
static char _loadBooterConfig_string[] = "_loadBooterConfig";
static char _loadConfigFile_string[] = "_loadConfigFile";
static char _loadOverrideConfig_string[] = "_loadOverrideConfig";
static char _loadSystemConfig_string[] = "_loadSystemConfig";
static char _load_all_modules_string[] = "_load_all_modules";
static char _load_module_string[] = "_load_module";
static char _loadedModules_string[] = "_loadedModules";
static char _longjmp_string[] = "_longjmp";
static char _lookup_all_symbols_string[] = "_lookup_all_symbols";
static char _lookup_symbol_string[] = "_lookup_symbol";
static char _lspci_string[] = "_lspci";
static char _malloc_string[] = "_malloc";
static char _malloc_init_string[] = "_malloc_init";
static char _matchVolumeToString_string[] = "_matchVolumeToString";
static char _memcmp_string[] = "_memcmp";
static char _memcpy_string[] = "_memcpy";
static char _memmove_string[] = "_memmove";
static char _memset_string[] = "_memset";
static char _moduleCallbacks_string[] = "_moduleCallbacks";
static char _moduleSymbols_string[] = "_moduleSymbols";
static char _module_loaded_string[] = "_module_loaded";
static char _msgbuf_string[] = "_msgbuf";
static char _msglog_string[] = "_msglog";
static char _multiboot_to_boot_string[] = "_multiboot_to_boot";
static char _newEmptyStringWithLength_string[] = "_newEmptyStringWithLength";
static char _newFilteredBVChain_string[] = "_newFilteredBVChain";
static char _newGPTBVRef_string[] = "_newGPTBVRef";
static char _newString_string[] = "_newString";
static char _newStringForKey_string[] = "_newStringForKey";
static char _newStringWithFormat_string[] = "_newStringWithFormat";
static char _newStringWithLength_string[] = "_newStringWithLength";
static char _open_string[] = "_open";
static char _open_bvdev_string[] = "_open_bvdev";
static char _opendir_string[] = "_opendir";
static char _parse_mach_string[] = "_parse_mach";
static char _pause_string[] = "_pause";
static char _pci_config_read16_string[] = "_pci_config_read16";
static char _pci_config_read32_string[] = "_pci_config_read32";
static char _pci_config_read8_string[] = "_pci_config_read8";
static char _pci_config_write16_string[] = "_pci_config_write16";
static char _pci_config_write32_string[] = "_pci_config_write32";
static char _pci_config_write8_string[] = "_pci_config_write8";
static char _platform_env_string[] = "_platform_env";
static char _prf_string[] = "_prf";
static char _printMemoryInfo_string[] = "_printMemoryInfo";
static char _printf_string[] = "_printf";
static char _processBootOptions_string[] = "_processBootOptions";
static char _promptForRescanOption_string[] = "_promptForRescanOption";
static char _ptol_string[] = "_ptol";
static char _putc_string[] = "_putc";
static char _putca_string[] = "_putca";
static char _putchar_string[] = "_putchar";
static char _rand_string[] = "_rand";
static char _random_string[] = "_random";
static char _random_free_string[] = "_random_free";
static char _random_init_string[] = "_random_init";
static char _re_set_env_string[] = "_re_set_env";
static char _re_set_env_copy_string[] = "_re_set_env_copy";
static char _read_string[] = "_read";
static char _readBootSector_string[] = "_readBootSector";
static char _readDefaultPlatformName_string[] = "_readDefaultPlatformName";
static char _readKeyboardShiftFlags_string[] = "_readKeyboardShiftFlags";
static char _readKeyboardStatus_string[] = "_readKeyboardStatus";
static char _readSMBIOS_string[] = "_readSMBIOS";
static char _readdir_string[] = "_readdir";
static char _realloc_string[] = "_realloc";
static char _rebase_location_string[] = "_rebase_location";
static char _rebase_macho_string[] = "_rebase_macho";
static char _ref_strings_string[] = "_ref_strings";
static char _register_hook_callback_string[] = "_register_hook_callback";
static char _replace_function_string[] = "_replace_function";
static char _replace_function_any_string[] = "_replace_function_any";
static char _replace_system_function_string[] = "_replace_system_function";
static char _rescanBIOSDevice_string[] = "_rescanBIOSDevice";
static char _reserveKern107BootStruct_string[] = "_reserveKern107BootStruct";
static char _reserveKern108BootStruct_string[] = "_reserveKern108BootStruct";
static char _reserveKernLegacyBootStruct_string[] = "_reserveKernLegacyBootStruct";
static char _root_pci_dev_string[] = "_root_pci_dev";
static char _safe_set_env_string[] = "_safe_set_env";
static char _safe_set_env_copy_string[] = "_safe_set_env_copy";
static char _scanBootVolumes_string[] = "_scanBootVolumes";
static char _scanDisks_string[] = "_scanDisks";
static char _scan_cpu_string[] = "_scan_cpu";
static char _scan_pci_bus_string[] = "_scan_pci_bus";
static char _scan_platform_string[] = "_scan_platform";
static char _scollPage_string[] = "_scollPage";
static char _selectBootVolume_string[] = "_selectBootVolume";
static char _setActiveDisplayPage_string[] = "_setActiveDisplayPage";
static char _setBootArgsVideoMode_string[] = "_setBootArgsVideoMode";
static char _setBootArgsVideoStruct_string[] = "_setBootArgsVideoStruct";
static char _setBootGlobals_string[] = "_setBootGlobals";
static char _setConsoleCursor_string[] = "_setConsoleCursor";
static char _setConsoleMsg_string[] = "_setConsoleMsg";
static char _setCursorPosition_string[] = "_setCursorPosition";
static char _setCursorType_string[] = "_setCursorType";
static char _setRootVolume_string[] = "_setRootVolume";
static char _setVBEMode_string[] = "_setVBEMode";
static char _setVBEPalette_string[] = "_setVBEPalette";
static char _set_env_string[] = "_set_env";
static char _set_env_copy_string[] = "_set_env_copy";
static char _setjmp_string[] = "_setjmp";
static char _setupBooterLog_string[] = "_setupBooterLog";
static char _setupDeviceProperties_string[] = "_setupDeviceProperties";
static char _setupFakeEfi_string[] = "_setupFakeEfi";
static char _setupSmbiosConfigFile_string[] = "_setupSmbiosConfigFile";
static char _setup_acpi_string[] = "_setup_acpi";
static char _setup_pci_devs_string[] = "_setup_pci_devs";
static char _showHelp_string[] = "_showHelp";
static char _showMessage_string[] = "_showMessage";
static char _showTextBuffer_string[] = "_showTextBuffer";
static char _showTextFile_string[] = "_showTextFile";
static char _sleep_string[] = "_sleep";
static char _slvprintf_string[] = "_slvprintf";
static char _sprintf_string[] = "_sprintf";
static char _sputc_string[] = "_sputc";
static char _srand_string[] = "_srand";
static char _startprog_string[] = "_startprog";
static char _stop_string[] = "_stop";
static char _strbreak_string[] = "_strbreak";
static char _strcat_string[] = "_strcat";
static char _strchr_string[] = "_strchr";
static char _strcmp_string[] = "_strcmp";
static char _strcpy_string[] = "_strcpy";
static char _strdup_string[] = "_strdup";
static char _string_string[] = "_string";
static char _stringdata_string[] = "_stringdata";
static char _stringlength_string[] = "_stringlength";
static char _strlcat_string[] = "_strlcat";
static char _strlcpy_string[] = "_strlcpy";
static char _strlen_string[] = "_strlen";
static char _strncat_string[] = "_strncat";
static char _strncmp_string[] = "_strncmp";
static char _strncpy_string[] = "_strncpy";
static char _strnlen_string[] = "_strnlen";
static char _strstr_string[] = "_strstr";
static char _strtol_string[] = "_strtol";
static char _strtoul_string[] = "_strtoul";
static char _strtouq_string[] = "_strtouq";
static char _testBiosread_string[] = "_testBiosread";
static char _testFAT32EFIBootSector_string[] = "_testFAT32EFIBootSector";
static char _textAddress_string[] = "_textAddress";
static char _textSection_string[] = "_textSection";
static char _time18_string[] = "_time18";
static char _unset_env_string[] = "_unset_env";
static char _usefixedrandom_string[] = "_usefixedrandom";
static char _utf_decodestr_string[] = "_utf_decodestr";
static char _utf_encodestr_string[] = "_utf_encodestr";
static char _verbose_string[] = "_verbose";
static char _video_mode_string[] = "_video_mode";
static char _waitThenReload_string[] = "_waitThenReload";
static char _write_string[] = "_write";
static char _zalloced_size_string[] = "_zalloced_size";
static char _zout_string[] = "_zout";
static char boot2_string[] = "boot2";
symbol_t symbolList[] = {
	{.symbol = _AllocateKernelMemory_string, .addr = 0x0002cdc8},
	{.symbol = _AllocateMemoryRange_string, .addr = 0x0002ce40},
	{.symbol = _BeFSGetDescription_string, .addr = 0x0002f9c3},
	{.symbol = _BeFSProbe_string, .addr = 0x0002f9aa},
	{.symbol = _BinaryUnicodeCompare_string, .addr = 0x000342bd},
	{.symbol = _CacheInit_string, .addr = 0x0002fb9e},
	{.symbol = _CacheRead_string, .addr = 0x0002fa5c},
	{.symbol = _CacheReset_string, .addr = 0x0002fa4d},
	{.symbol = _CreateUUIDString_string, .addr = 0x00024b2f},
	{.symbol = _DT__AddChild_string, .addr = 0x00032e3a},
	{.symbol = _DT__AddProperty_string, .addr = 0x00032bfa},
	{.symbol = _DT__Finalize_string, .addr = 0x00032db1},
	{.symbol = _DT__FindNode_string, .addr = 0x00032f57},
	{.symbol = _DT__FlattenDeviceTree_string, .addr = 0x00032d41},
	{.symbol = _DT__FreeNode_string, .addr = 0x00032bb1},
	{.symbol = _DT__FreeProperty_string, .addr = 0x00032b9b},
	{.symbol = _DT__GetName_string, .addr = 0x00032bc7},
	{.symbol = _DT__Initialize_string, .addr = 0x00032ef9},
	{.symbol = _DecodeKernel_string, .addr = 0x0002297c},
	{.symbol = _DecodeMachO_string, .addr = 0x00026547},
	{.symbol = _EX2GetDescription_string, .addr = 0x0002fc73},
	{.symbol = _EX2Probe_string, .addr = 0x0002fc5a},
	{.symbol = _EXFATGetDescription_string, .addr = 0x00034748},
	{.symbol = _EXFATGetUUID_string, .addr = 0x000346d5},
	{.symbol = _EXFATProbe_string, .addr = 0x000346b2},
	{.symbol = _FastRelString_string, .addr = 0x000343d7},
	{.symbol = _FastUnicodeCompare_string, .addr = 0x00034457},
	{.symbol = _FileLoadDrivers_string, .addr = 0x00022575},
	{.symbol = _FindAcpiTables_string, .addr = 0x000331bf},
	{.symbol = _FreeBSDGetDescription_string, .addr = 0x0002fd20},
	{.symbol = _FreeBSDProbe_string, .addr = 0x0002fd07},
	{.symbol = _GPT_BASICDATA2_GUID_string, .addr = 0x000394e8},
	{.symbol = _GPT_BASICDATA_GUID_string, .addr = 0x000394d8},
	{.symbol = _GPT_BOOT_GUID_string, .addr = 0x000394b8},
	{.symbol = _GPT_EFISYS_GUID_string, .addr = 0x000394c8},
	{.symbol = _GPT_HFS_GUID_string, .addr = 0x000394a8},
	{.symbol = _Gdt_string, .addr = 0x000204bc},
	{.symbol = _Gdtr_string, .addr = 0x000204f4},
	{.symbol = _GetChecksum_string, .addr = 0x000330a3},
	{.symbol = _GetDirEntry_string, .addr = 0x00024f59},
	{.symbol = _GetFileInfo_string, .addr = 0x00024f94},
	{.symbol = _GetgPlatformName_string, .addr = 0x00025381},
	{.symbol = _GetgRootDevice_string, .addr = 0x00025395},
	{.symbol = _Getgboardproduct_string, .addr = 0x0002538b},
	{.symbol = _HFSFree_string, .addr = 0x0002ff81},
	{.symbol = _HFSGetDescription_string, .addr = 0x0003127d},
	{.symbol = _HFSGetDirEntry_string, .addr = 0x00030f97},
	{.symbol = _HFSGetFileBlock_string, .addr = 0x0003132d},
	{.symbol = _HFSGetUUID_string, .addr = 0x00030f62},
	{.symbol = _HFSInitPartition_string, .addr = 0x00030c1a},
	{.symbol = _HFSLoadFile_string, .addr = 0x0003122f},
	{.symbol = _HFSLoadVerbose_string, .addr = 0x0003e368},
	{.symbol = _HFSProbe_string, .addr = 0x0003124d},
	{.symbol = _HFSReadFile_string, .addr = 0x00031086},
	{.symbol = _Idtr_prot_string, .addr = 0x00020504},
	{.symbol = _Idtr_real_string, .addr = 0x000204fc},
	{.symbol = _InitBootPrompt_string, .addr = 0x00022aea},
	{.symbol = _InitDriverSupport_string, .addr = 0x000226d8},
	{.symbol = _LoadDriverMKext_string, .addr = 0x000220ff},
	{.symbol = _LoadDriverPList_string, .addr = 0x000221c1},
	{.symbol = _LoadDrivers_string, .addr = 0x000227d9},
	{.symbol = _LoadFile_string, .addr = 0x00025179},
	{.symbol = _LoadMatchedModules_string, .addr = 0x00021f94},
	{.symbol = _LoadThinFatFile_string, .addr = 0x00025050},
	{.symbol = _LoadVolumeFile_string, .addr = 0x000247fe},
	{.symbol = _MD5Final_string, .addr = 0x0002ec30},
	{.symbol = _MD5Init_string, .addr = 0x0002e477},
	{.symbol = _MD5Update_string, .addr = 0x0002eb4c},
	{.symbol = _MSDOSFree_string, .addr = 0x0003140b},
	{.symbol = _MSDOSGetDescription_string, .addr = 0x000325c8},
	{.symbol = _MSDOSGetDirEntry_string, .addr = 0x0003218d},
	{.symbol = _MSDOSGetFileBlock_string, .addr = 0x00032459},
	{.symbol = _MSDOSGetUUID_string, .addr = 0x00031e21},
	{.symbol = _MSDOSInitPartition_string, .addr = 0x00031c52},
	{.symbol = _MSDOSLoadFile_string, .addr = 0x000320d0},
	{.symbol = _MSDOSProbe_string, .addr = 0x000320ee},
	{.symbol = _MSDOSReadFile_string, .addr = 0x00031ea4},
	{.symbol = _MatchLibraries_string, .addr = 0x00021efa},
	{.symbol = _NTFSGetDescription_string, .addr = 0x00032817},
	{.symbol = _NTFSGetUUID_string, .addr = 0x00032783},
	{.symbol = _NTFSProbe_string, .addr = 0x00032752},
	{.symbol = _OpenBSDGetDescription_string, .addr = 0x00032b07},
	{.symbol = _OpenBSDProbe_string, .addr = 0x00032aee},
	{.symbol = _ParseXMLFile_string, .addr = 0x0002b193},
	{.symbol = _ReadFileAtOffset_string, .addr = 0x0002513b},
	{.symbol = _Register_Acpi_Efi_string, .addr = 0x0002b039},
	{.symbol = _Register_Smbios_Efi_string, .addr = 0x0002a0fe},
	{.symbol = _SetgPlatformName_string, .addr = 0x00025374},
	{.symbol = _SetgRootDevice_string, .addr = 0x0002535a},
	{.symbol = _Setgboardproduct_string, .addr = 0x00025367},
	{.symbol = _ThinFatFile_string, .addr = 0x0002684b},
	{.symbol = _XMLCastArray_string, .addr = 0x0002d03d},
	{.symbol = _XMLCastBoolean_string, .addr = 0x0002d0aa},
	{.symbol = _XMLCastDict_string, .addr = 0x0002d056},
	{.symbol = _XMLCastInteger_string, .addr = 0x0002d0c0},
	{.symbol = _XMLCastString_string, .addr = 0x0002d06f},
	{.symbol = _XMLCastStringOffset_string, .addr = 0x0002d08c},
	{.symbol = _XMLDecode_string, .addr = 0x0002d503},
	{.symbol = _XMLFreeTag_string, .addr = 0x0002d0e5},
	{.symbol = _XMLGetElement_string, .addr = 0x0002cf43},
	{.symbol = _XMLGetProperty_string, .addr = 0x0002d1e8},
	{.symbol = _XMLIsType_string, .addr = 0x0002d022},
	{.symbol = _XMLParseFile_string, .addr = 0x0002dee2},
	{.symbol = _XMLParseNextTag_string, .addr = 0x0002d794},
	{.symbol = _XMLTagCount_string, .addr = 0x0002cea9},
	{.symbol = __DATA__bss__begin_string, .addr = 0x0003e890},
	{.symbol = __DATA__bss__end_string, .addr = 0x000403c0},
	{.symbol = __DATA__common__begin_string, .addr = 0x000403c0},
	{.symbol = __DATA__common__end_string, .addr = 0x00040800},
	{.symbol = ___bzero_string, .addr = 0x00034de7},
	{.symbol = ___convertImage_string, .addr = 0x00021ddb},
	{.symbol = ___decodeRLE_string, .addr = 0x00021700},
	{.symbol = ___divdi3_string, .addr = 0x00035bee},
	{.symbol = ___drawColorRectangle_string, .addr = 0x00021ca6},
	{.symbol = ___drawDataRectangle_string, .addr = 0x00021666},
	{.symbol = ___getNumberArrayFromProperty_string, .addr = 0x000215f9},
	{.symbol = ___getVESAModeWithProperties_string, .addr = 0x0002174d},
	{.symbol = ___moddi3_string, .addr = 0x00035c5c},
	{.symbol = ___qdivrem_string, .addr = 0x00035ccd},
	{.symbol = ___setVESAGraphicsMode_string, .addr = 0x000219a9},
	{.symbol = ___setVideoMode_string, .addr = 0x00021b02},
	{.symbol = ___udivdi3_string, .addr = 0x000358bc},
	{.symbol = ___umoddi3_string, .addr = 0x000358d4},
	{.symbol = __bp_string, .addr = 0x000203aa},
	{.symbol = __hi_malloc_string, .addr = 0x00024468},
	{.symbol = __hi_strdup_string, .addr = 0x00024479},
	{.symbol = __prot_to_real_string, .addr = 0x0002032d},
	{.symbol = __real_to_prot_string, .addr = 0x000202df},
	{.symbol = __sp_string, .addr = 0x000203a7},
	{.symbol = __switch_stack_string, .addr = 0x000203ad},
	{.symbol = _addBootArg_string, .addr = 0x00023665},
	{.symbol = _addConfigurationTable_string, .addr = 0x0002a34a},
	{.symbol = _add_symbol_string, .addr = 0x000294c7},
	{.symbol = _adler32_string, .addr = 0x00034af3},
	{.symbol = _arc4_init_string, .addr = 0x000262a4},
	{.symbol = _arc4rand_string, .addr = 0x0002647d},
	{.symbol = _arc4random_string, .addr = 0x0002652f},
	{.symbol = _archCpuType_string, .addr = 0x0003e280},
	{.symbol = _ascii_hex_to_int_string, .addr = 0x000333d5},
	{.symbol = _atoi_string, .addr = 0x000349bd},
	{.symbol = _b_lseek_string, .addr = 0x00024cd1},
	{.symbol = _bcopy_string, .addr = 0x00035342},
	{.symbol = _bcopy16_string, .addr = 0x00035322},
	{.symbol = _bcopy_no_overwrite_string, .addr = 0x00035313},
	{.symbol = _bgetc_string, .addr = 0x0002cb5a},
	{.symbol = _bind_location_string, .addr = 0x0002947a},
	{.symbol = _bind_macho_string, .addr = 0x000297ee},
	{.symbol = _bios_string, .addr = 0x000203dd},
	{.symbol = _biosDevIsCDROM_string, .addr = 0x00026a03},
	{.symbol = _biosread_string, .addr = 0x0002c60b},
	{.symbol = _boot_string, .addr = 0x000215de},
	{.symbol = _bootArgs_string, .addr = 0x0003e294},
	{.symbol = _bootArgs107_string, .addr = 0x0003e29c},
	{.symbol = _bootArgs108_string, .addr = 0x0003e2a0},
	{.symbol = _bootArgsLegacy_string, .addr = 0x0003e298},
	{.symbol = _bootInfo_string, .addr = 0x0003e2a4},
	{.symbol = _bsearch_string, .addr = 0x00034bbf},
	{.symbol = _build_pci_dt_string, .addr = 0x0002e3f8},
	{.symbol = _bzero_string, .addr = 0x00034de7},
	{.symbol = _chainLoad_string, .addr = 0x00024779},
	{.symbol = _chainbootdev_string, .addr = 0x000204b0},
	{.symbol = _chainbootflag_string, .addr = 0x000204b1},
	{.symbol = _checksum8_string, .addr = 0x00034ad9},
	{.symbol = _clearBootArgs_string, .addr = 0x000236bd},
	{.symbol = _clearScreenRows_string, .addr = 0x0002c2cf},
	{.symbol = _close_string, .addr = 0x00024814},
	{.symbol = _closedir_string, .addr = 0x00024a18},
	{.symbol = _common_boot_string, .addr = 0x00020952},
	{.symbol = _continue_at_low_address_string, .addr = 0x000202b4},
	{.symbol = _convertHexStr2Binary_string, .addr = 0x00033430},
	{.symbol = _copyArgument_string, .addr = 0x00022f07},
	{.symbol = _copyMultibootInfo_string, .addr = 0x000244ff},
	{.symbol = _crc32_string, .addr = 0x000358f7},
	{.symbol = _cursor_string, .addr = 0x0003e320},
	{.symbol = _decompress_lzss_string, .addr = 0x0002df5e},
	{.symbol = _delay_string, .addr = 0x0002c217},
	{.symbol = _determine_safe_hi_addr_string, .addr = 0x000243d9},
	{.symbol = _devices_number_string, .addr = 0x0003e488},
	{.symbol = _devprop_add_device_string, .addr = 0x00033e7b},
	{.symbol = _devprop_add_value_string, .addr = 0x00033d41},
	{.symbol = _devprop_create_string_string, .addr = 0x00033cfd},
	{.symbol = _devprop_free_string_string, .addr = 0x00033ac4},
	{.symbol = _devprop_generate_string_string, .addr = 0x00033b37},
	{.symbol = _diskFreeMap_string, .addr = 0x00026a82},
	{.symbol = _diskIsCDROM_string, .addr = 0x00026a27},
	{.symbol = _diskRead_string, .addr = 0x0002754a},
	{.symbol = _diskResetBootVolumes_string, .addr = 0x00027006},
	{.symbol = _diskScanBootVolumes_string, .addr = 0x00027864},
	{.symbol = _diskSeek_string, .addr = 0x00026905},
	{.symbol = _dump_pci_dt_string, .addr = 0x0002e22e},
	{.symbol = _ebiosEjectMedia_string, .addr = 0x0002c39a},
	{.symbol = _ebiosread_string, .addr = 0x0002c538},
	{.symbol = _ebioswrite_string, .addr = 0x0002c447},
	{.symbol = _efi_guid_compare_string, .addr = 0x00035950},
	{.symbol = _efi_guid_is_null_string, .addr = 0x00035928},
	{.symbol = _efi_guid_unparse_upper_string, .addr = 0x000359a1},
	{.symbol = _efi_inject_get_devprop_string_string, .addr = 0x00034150},
	{.symbol = _enableA20_string, .addr = 0x0002918b},
	{.symbol = _enable_pci_devs_string, .addr = 0x0002e10b},
	{.symbol = _error_string, .addr = 0x0002bd22},
	{.symbol = _execute_hook_string, .addr = 0x0002a0a3},
	{.symbol = _file_size_string, .addr = 0x0002483e},
	{.symbol = _finalizeBootStruct_string, .addr = 0x0002850c},
	{.symbol = _finalizeEFIConfigTable_string, .addr = 0x0002a15e},
	{.symbol = _free_string, .addr = 0x00034f6d},
	{.symbol = _freeFilteredBVChain_string, .addr = 0x00026a4e},
	{.symbol = _free_platform_env_string, .addr = 0x000253ad},
	{.symbol = _gAppleBootPictRLE_string, .addr = 0x00038be0},
	{.symbol = _gBIOSBootVolume_string, .addr = 0x0003e23c},
	{.symbol = _gBinaryAddress_string, .addr = 0x00040418},
	{.symbol = _gBootFileType_string, .addr = 0x000403c0},
	{.symbol = _gBootVolume_string, .addr = 0x000403c4},
	{.symbol = _gCompareTable_string, .addr = 0x000407f0},
	{.symbol = _gCompareTableCompressed_string, .addr = 0x0003e788},
	{.symbol = _gEfiAcpi20TableGuid_string, .addr = 0x0003e2ec},
	{.symbol = _gEfiAcpiTableGuid_string, .addr = 0x0003e2dc},
	{.symbol = _gEfiConfigurationTable32_string, .addr = 0x00040420},
	{.symbol = _gEfiConfigurationTable64_string, .addr = 0x000404f0},
	{.symbol = _gEfiConfigurationTableNode_string, .addr = 0x0003e2d8},
	{.symbol = _gEfiMpsTableGuid_string, .addr = 0x0003e2fc},
	{.symbol = _gEfiSmbiosTableGuid_string, .addr = 0x00039628},
	{.symbol = _gErrors_string, .addr = 0x000403c8},
	{.symbol = _gFSLoadAddress_string, .addr = 0x0003e238},
	{.symbol = _gHaveKernelCache_string, .addr = 0x000403c9},
	{.symbol = _gLowerCaseTable_string, .addr = 0x000407f4},
	{.symbol = _gLowerCaseTableCompressed_string, .addr = 0x0003e4b0},
	{.symbol = _gMemoryMapNode_string, .addr = 0x0003e2a8},
	{.symbol = _gNumTables32_string, .addr = 0x0003e30c},
	{.symbol = _gNumTables64_string, .addr = 0x0003e310},
	{.symbol = _gST32_string, .addr = 0x0003e2d0},
	{.symbol = _gST64_string, .addr = 0x0003e2d4},
	{.symbol = _gVerboseMode_string, .addr = 0x000403ca},
	{.symbol = _getBVChainForBIOSDev_string, .addr = 0x000268e6},
	{.symbol = _getBoolForKey_string, .addr = 0x0002ba4f},
	{.symbol = _getBootArgs_string, .addr = 0x00028502},
	{.symbol = _getBootOptions_string, .addr = 0x0002377f},
	{.symbol = _getBootVolumeDescription_string, .addr = 0x00026ca7},
	{.symbol = _getBootVolumeRef_string, .addr = 0x00024dd4},
	{.symbol = _getBvChain_string, .addr = 0x00020540},
	{.symbol = _getColorForKey_string, .addr = 0x0002b785},
	{.symbol = _getConsoleCursor_string, .addr = 0x0002bc9e},
	{.symbol = _getConsoleMsg_string, .addr = 0x0002bc94},
	{.symbol = _getConventionalMemorySize_string, .addr = 0x0002c6e4},
	{.symbol = _getCursorPositionAndType_string, .addr = 0x0002c2f2},
	{.symbol = _getDeviceDescription_string, .addr = 0x000248a6},
	{.symbol = _getDimensionForKey_string, .addr = 0x0002b827},
	{.symbol = _getEDID_string, .addr = 0x0002cd60},
	{.symbol = _getExtendedMemorySize_string, .addr = 0x0002c704},
	{.symbol = _getIntForKey_string, .addr = 0x0002b965},
	{.symbol = _getKernelCachePath_string, .addr = 0x000205d3},
	{.symbol = _getMemoryInfoString_string, .addr = 0x00022e11},
	{.symbol = _getMemoryMap_string, .addr = 0x0002c9c7},
	{.symbol = _getNextArg_string, .addr = 0x0002b0e0},
	{.symbol = _getPciRootUID_string, .addr = 0x000341ee},
	{.symbol = _getPlatformName_string, .addr = 0x00028f1d},
	{.symbol = _getSmbiosOriginal_string, .addr = 0x0002bffc},
	{.symbol = _getStringForKey_string, .addr = 0x0002baf5},
	{.symbol = _getStringFromUUID_string, .addr = 0x000335e3},
	{.symbol = _getUUIDFromString_string, .addr = 0x00033510},
	{.symbol = _getVBEInfo_string, .addr = 0x0002cd1f},
	{.symbol = _getVBEModeInfo_string, .addr = 0x0002ccd5},
	{.symbol = _getValueForBootKey_string, .addr = 0x0002b514},
	{.symbol = _getValueForConfigTableKey_string, .addr = 0x0002b5bb},
	{.symbol = _getValueForKey_string, .addr = 0x0002b670},
	{.symbol = _getVideoMode_string, .addr = 0x000284ac},
	{.symbol = _getVolumeLabelAlias_string, .addr = 0x00026bbe},
	{.symbol = _get_callback_string, .addr = 0x00029761},
	{.symbol = _get_drive_info_string, .addr = 0x0002c88a},
	{.symbol = _get_env_string, .addr = 0x000259a1},
	{.symbol = _get_env_ptr_string, .addr = 0x0002592f},
	{.symbol = _get_env_var_string, .addr = 0x00025964},
	{.symbol = _get_num_tables_string, .addr = 0x00033029},
	{.symbol = _get_num_tables64_string, .addr = 0x0003303a},
	{.symbol = _get_pci_dev_path_string, .addr = 0x0002e16f},
	{.symbol = _getc_string, .addr = 0x0002bed8},
	{.symbol = _getchar_string, .addr = 0x0002bfae},
	{.symbol = _gfps_ptr_string, .addr = 0x000405e0},
	{.symbol = _h_buf_error_string, .addr = 0x000403d0},
	{.symbol = _halt_string, .addr = 0x00020383},
	{.symbol = _handle_symtable_string, .addr = 0x00029514},
	{.symbol = _hi_multiboot_string, .addr = 0x00024635},
	{.symbol = _imps_apic_cpu_map_string, .addr = 0x000405f0},
	{.symbol = _imps_cpu_apic_map_string, .addr = 0x000406f0},
	{.symbol = _imps_enabled_string, .addr = 0x0003e3ac},
	{.symbol = _imps_lapic_addr_string, .addr = 0x0003e3b4},
	{.symbol = _imps_num_cpus_string, .addr = 0x0003e3b0},
	{.symbol = _imps_probe_string, .addr = 0x000339f1},
	{.symbol = _imps_release_cpus_string, .addr = 0x0003e3a8},
	{.symbol = _initBooterLog_string, .addr = 0x0002bf71},
	{.symbol = _initKernBootStruct_string, .addr = 0x00028d9e},
	{.symbol = _init_module_system_string, .addr = 0x00029fc3},
	{.symbol = _init_ut_fnc_string, .addr = 0x0002bff7},
	{.symbol = _initialize_runtime_string, .addr = 0x0002159c},
	{.symbol = _is_module_loaded_string, .addr = 0x0002978f},
	{.symbol = _is_no_emulation_string, .addr = 0x0002c80b},
	{.symbol = _itoa_string, .addr = 0x000349e1},
	{.symbol = _jump_to_chainbooter_string, .addr = 0x000202ca},
	{.symbol = _loadBooterConfig_string, .addr = 0x0002b383},
	{.symbol = _loadConfigFile_string, .addr = 0x0002b444},
	{.symbol = _loadOverrideConfig_string, .addr = 0x0002b2d3},
	{.symbol = _loadSystemConfig_string, .addr = 0x0002b21e},
	{.symbol = _load_all_modules_string, .addr = 0x00029f24},
	{.symbol = _load_module_string, .addr = 0x00029de3},
	{.symbol = _loadedModules_string, .addr = 0x0003e2c4},
	{.symbol = _longjmp_string, .addr = 0x0003589e},
	{.symbol = _lookup_all_symbols_string, .addr = 0x0002966f},
	{.symbol = _lookup_symbol_string, .addr = 0x0003e2cc},
	{.symbol = _lspci_string, .addr = 0x00023540},
	{.symbol = _malloc_string, .addr = 0x0003529c},
	{.symbol = _malloc_init_string, .addr = 0x00034e09},
	{.symbol = _matchVolumeToString_string, .addr = 0x00026ab4},
	{.symbol = _memcmp_string, .addr = 0x00034b8c},
	{.symbol = _memcpy_string, .addr = 0x000352f1},
	{.symbol = _memmove_string, .addr = 0x00034c49},
	{.symbol = _memset_string, .addr = 0x00034dba},
	{.symbol = _moduleCallbacks_string, .addr = 0x0003e2c0},
	{.symbol = _moduleSymbols_string, .addr = 0x0003e2c8},
	{.symbol = _module_loaded_string, .addr = 0x000294a1},
	{.symbol = _msgbuf_string, .addr = 0x0003e31c},
	{.symbol = _msglog_string, .addr = 0x0002be78},
	{.symbol = _multiboot_to_boot_string, .addr = 0x000247be},
	{.symbol = _newEmptyStringWithLength_string, .addr = 0x0002bc57},
	{.symbol = _newFilteredBVChain_string, .addr = 0x00026dc0},
	{.symbol = _newGPTBVRef_string, .addr = 0x0002764e},
	{.symbol = _newString_string, .addr = 0x0002bc2c},
	{.symbol = _newStringForKey_string, .addr = 0x0002bb86},
	{.symbol = _newStringWithFormat_string, .addr = 0x0002bcc2},
	{.symbol = _newStringWithLength_string, .addr = 0x0002b17b},
	{.symbol = _open_string, .addr = 0x00024f30},
	{.symbol = _open_bvdev_string, .addr = 0x000251ad},
	{.symbol = _opendir_string, .addr = 0x00024ede},
	{.symbol = _parse_mach_string, .addr = 0x00029b3b},
	{.symbol = _pause_string, .addr = 0x0002bfe3},
	{.symbol = _pci_config_read16_string, .addr = 0x0002e099},
	{.symbol = _pci_config_read32_string, .addr = 0x0002e0c4},
	{.symbol = _pci_config_read8_string, .addr = 0x0002e06f},
	{.symbol = _pci_config_write16_string, .addr = 0x0002e0dc},
	{.symbol = _pci_config_write32_string, .addr = 0x0002e3dd},
	{.symbol = _pci_config_write8_string, .addr = 0x0002e3af},
	{.symbol = _platform_env_string, .addr = 0x0003e27c},
	{.symbol = _prf_string, .addr = 0x000359ed},
	{.symbol = _printMemoryInfo_string, .addr = 0x00023594},
	{.symbol = _printf_string, .addr = 0x0002bdc8},
	{.symbol = _processBootOptions_string, .addr = 0x00022f8e},
	{.symbol = _promptForRescanOption_string, .addr = 0x00022b2b},
	{.symbol = _ptol_string, .addr = 0x0003499b},
	{.symbol = _putc_string, .addr = 0x0002c410},
	{.symbol = _putca_string, .addr = 0x0002c3d0},
	{.symbol = _putchar_string, .addr = 0x0002beef},
	{.symbol = _rand_string, .addr = 0x00034b6b},
	{.symbol = _random_string, .addr = 0x00028f43},
	{.symbol = _random_free_string, .addr = 0x00028f31},
	{.symbol = _random_init_string, .addr = 0x0002902a},
	{.symbol = _re_set_env_string, .addr = 0x000258f2},
	{.symbol = _re_set_env_copy_string, .addr = 0x000260f8},
	{.symbol = _read_string, .addr = 0x00024c13},
	{.symbol = _readBootSector_string, .addr = 0x000275f1},
	{.symbol = _readDefaultPlatformName_string, .addr = 0x0002c19d},
	{.symbol = _readKeyboardShiftFlags_string, .addr = 0x0002c7b1},
	{.symbol = _readKeyboardStatus_string, .addr = 0x0002c7d8},
	{.symbol = _readSMBIOS_string, .addr = 0x0002c07c},
	{.symbol = _readdir_string, .addr = 0x00024864},
	{.symbol = _realloc_string, .addr = 0x000352b0},
	{.symbol = _rebase_location_string, .addr = 0x00029464},
	{.symbol = _rebase_macho_string, .addr = 0x000291f5},
	{.symbol = _ref_strings_string, .addr = 0x0003e324},
	{.symbol = _register_hook_callback_string, .addr = 0x0002a00b},
	{.symbol = _replace_function_string, .addr = 0x000296f4},
	{.symbol = _replace_function_any_string, .addr = 0x0002973a},
	{.symbol = _replace_system_function_string, .addr = 0x0002974c},
	{.symbol = _rescanBIOSDevice_string, .addr = 0x0002706d},
	{.symbol = _reserveKern107BootStruct_string, .addr = 0x00028b2a},
	{.symbol = _reserveKern108BootStruct_string, .addr = 0x000288b6},
	{.symbol = _reserveKernLegacyBootStruct_string, .addr = 0x00028707},
	{.symbol = _root_pci_dev_string, .addr = 0x000403cc},
	{.symbol = _safe_set_env_string, .addr = 0x000260ba},
	{.symbol = _safe_set_env_copy_string, .addr = 0x000260e1},
	{.symbol = _scanBootVolumes_string, .addr = 0x00024a3e},
	{.symbol = _scanDisks_string, .addr = 0x000252c4},
	{.symbol = _scan_cpu_string, .addr = 0x0002ec9e},
	{.symbol = _scan_pci_bus_string, .addr = 0x0002e286},
	{.symbol = _scan_platform_string, .addr = 0x0002539f},
	{.symbol = _scollPage_string, .addr = 0x0002c276},
	{.symbol = _selectBootVolume_string, .addr = 0x00024905},
	{.symbol = _setActiveDisplayPage_string, .addr = 0x0002c24d},
	{.symbol = _setBootArgsVideoMode_string, .addr = 0x0002849c},
	{.symbol = _setBootArgsVideoStruct_string, .addr = 0x000284b9},
	{.symbol = _setBootGlobals_string, .addr = 0x00024cfd},
	{.symbol = _setConsoleCursor_string, .addr = 0x0002bcb5},
	{.symbol = _setConsoleMsg_string, .addr = 0x0002bca8},
	{.symbol = _setCursorPosition_string, .addr = 0x0002c361},
	{.symbol = _setCursorType_string, .addr = 0x0002c337},
	{.symbol = _setRootVolume_string, .addr = 0x00024886},
	{.symbol = _setVBEMode_string, .addr = 0x0002cc87},
	{.symbol = _setVBEPalette_string, .addr = 0x0002cc2d},
	{.symbol = _set_env_string, .addr = 0x00025fae},
	{.symbol = _set_env_copy_string, .addr = 0x00025f97},
	{.symbol = _setjmp_string, .addr = 0x00035884},
	{.symbol = _setupBooterLog_string, .addr = 0x0002bf2b},
	{.symbol = _setupDeviceProperties_string, .addr = 0x00034180},
	{.symbol = _setupFakeEfi_string, .addr = 0x0002a50f},
	{.symbol = _setupSmbiosConfigFile_string, .addr = 0x0002a274},
	{.symbol = _setup_acpi_string, .addr = 0x0002a46a},
	{.symbol = _setup_pci_devs_string, .addr = 0x0002e13a},
	{.symbol = _showHelp_string, .addr = 0x00022d4c},
	{.symbol = _showMessage_string, .addr = 0x00022d30},
	{.symbol = _showTextBuffer_string, .addr = 0x00022b49},
	{.symbol = _showTextFile_string, .addr = 0x00022c98},
	{.symbol = _sleep_string, .addr = 0x0002cbb0},
	{.symbol = _slvprintf_string, .addr = 0x000353ab},
	{.symbol = _sprintf_string, .addr = 0x000353e5},
	{.symbol = _sputc_string, .addr = 0x0002bc70},
	{.symbol = _srand_string, .addr = 0x00034b5e},
	{.symbol = _startprog_string, .addr = 0x0002038d},
	{.symbol = _stop_string, .addr = 0x0002be3e},
	{.symbol = _strbreak_string, .addr = 0x00034c63},
	{.symbol = _strcat_string, .addr = 0x00034a9a},
	{.symbol = _strchr_string, .addr = 0x00034aba},
	{.symbol = _strcmp_string, .addr = 0x00034882},
	{.symbol = _strcpy_string, .addr = 0x000348e0},
	{.symbol = _strdup_string, .addr = 0x00034c03},
	{.symbol = _string_string, .addr = 0x0003e48c},
	{.symbol = _stringdata_string, .addr = 0x0003e490},
	{.symbol = _stringlength_string, .addr = 0x0003e494},
	{.symbol = _strlcat_string, .addr = 0x00034cf6},
	{.symbol = _strlcpy_string, .addr = 0x00034956},
	{.symbol = _strlen_string, .addr = 0x00034a63},
	{.symbol = _strncat_string, .addr = 0x00034a31},
	{.symbol = _strncmp_string, .addr = 0x000348ab},
	{.symbol = _strncpy_string, .addr = 0x000348f8},
	{.symbol = _strnlen_string, .addr = 0x00034a7d},
	{.symbol = _strstr_string, .addr = 0x00034d53},
	{.symbol = _strtol_string, .addr = 0x00035421},
	{.symbol = _strtoul_string, .addr = 0x00035582},
	{.symbol = _strtouq_string, .addr = 0x000356d2},
	{.symbol = _testBiosread_string, .addr = 0x0002848a},
	{.symbol = _testFAT32EFIBootSector_string, .addr = 0x00027579},
	{.symbol = _textAddress_string, .addr = 0x0003e2b0},
	{.symbol = _textSection_string, .addr = 0x0003e2b8},
	{.symbol = _time18_string, .addr = 0x0002c777},
	{.symbol = _unset_env_string, .addr = 0x000258db},
	{.symbol = _usefixedrandom_string, .addr = 0x00028f10},
	{.symbol = _utf_decodestr_string, .addr = 0x0003452a},
	{.symbol = _utf_encodestr_string, .addr = 0x00034605},
	{.symbol = _verbose_string, .addr = 0x0002bd49},
	{.symbol = _video_mode_string, .addr = 0x0002c6bb},
	{.symbol = _waitThenReload_string, .addr = 0x000244a1},
	{.symbol = _write_string, .addr = 0x00024c72},
	{.symbol = _zalloced_size_string, .addr = 0x000407f8},
	{.symbol = _zout_string, .addr = 0x000407fc},
	{.symbol = boot2_string, .addr = 0x00020200},
};
